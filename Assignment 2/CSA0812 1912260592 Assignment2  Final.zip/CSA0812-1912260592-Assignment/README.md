# CSA0812-1912260592-Assignment

**Name:** Zoyaa Shaik  **Register No.:** 1912260592
**Python version:** 3.12  **Libraries:** standard library only (see requirements.txt)

| Task | Command | Result note |
|------|---------|-------------|
| Q1 | `python Q1/q1_subsidy.py` | Separate `if` gives double subsidy at 100 units with ration card; `if-elif-else` gives exactly one result. |
| Q2 | `python Q2/q2_otp.py` | while / for-else designs; blank entry not counted; +2 attempts rule added. |
| Q3 | `python Q3/q3_plate.py` | normalise / is_valid / format; slicing and regex agree on all inputs. |
| Q4 | `python Q4/q4_text.py` | Three runs at 1,000 / 10,000 / 200,000 lines; join, += , f-string, StringIO compared. |
| Q5 | `python Q5/q5_orders.py` | Mutable default bug shown with `__defaults__`; fixed with `None`. |
| Q6 | `python Q6/q6_steps.py` | Naive vs memo call counts; RecursionError at n=1000; loop alternative. |
| Q7 | `python Q7/q7_redesign.py` | Redesign of Q6 naive recursion; counts, times, memory. |
