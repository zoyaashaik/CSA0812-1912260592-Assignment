"""Q1 - Decisions with many boundaries: State electricity subsidy."""
import time

# ---- Version A: separate if statements (the buggy design) -------------
def subsidy_separate_if(units, ration_card, has_80plus):
    result = []
    if units <= 100:
        result.append("FULL")
    if units <= 200 and ration_card:          # BUG: forgot the lower bound 101
        result.append("PARTIAL")
    if units > 200 and has_80plus:
        result.append("ELDER")
    return result or ["NONE"]

# ---- Version B: if-elif-else (exactly one outcome) ---------------------
def subsidy_elif(units, ration_card, has_80plus):
    if units <= 100:
        return "FULL"
    elif 101 <= units <= 200:
        return "PARTIAL" if ration_card else "NONE"
    else:                                  # units > 200
        return "ELDER" if has_80plus else "NONE"

# ---- Alternative: lookup of (upper limit, decision) pairs --------------
SLABS = [(100, "FULL"), (200, "RATION_ONLY")]
def subsidy_table(units, ration_card, has_80plus):
    for limit, label in SLABS:
        if units <= limit:
            if label == "RATION_ONLY":
                return "PARTIAL" if ration_card else "NONE"
            return label
    return "ELDER" if has_80plus else "NONE"

tests = [  # (units, ration_card, member_above_80)
    (50,  False, False),
    (100, True,  False),   # boundary (ration card holder)
    (101, True,  False),   # boundary
    (101, False, False),
    (200, True,  False),   # boundary
    (200, False, True),
    (201, False, True),    # boundary
    (201, False, False),
]
expected = ["FULL", "FULL", "PARTIAL", "NONE", "PARTIAL", "NONE", "ELDER", "NONE"]

print(f"{'units':>5} {'ration':>6} {'80+':>5} | {'predicted':9} | {'separate if':22} | {'if-elif-else':9} | table")
for t, e in zip(tests, expected):
    a, b, c = subsidy_separate_if(*t), subsidy_elif(*t), subsidy_table(*t)
    flag = "  <-- DOUBLE SUBSIDY" if len(a) > 1 else ""
    print(f"{t[0]:>5} {str(t[1]):>6} {str(t[2]):>5} | {e:9} | {str(a):22} | {b:9} | {c}{flag}")
    assert b == e and c == e, "elif / table version differs from prediction"

# ---- Timing: if-elif vs table lookup, 1,000,000 decisions --------------
N = 1_000_000
for name, fn in [("if-elif-else", subsidy_elif), ("table lookup", subsidy_table)]:
    s = time.perf_counter()
    for i in range(N):
        fn(i % 300, True, False)
    print(f"{name:13}: {time.perf_counter()-s:.3f} s for {N:,} decisions")
