"""Q3 - Vehicle registration number validator (string methods and slicing only, no regex in the solution)."""
import re, time

def normalise(text):
    """'tn 09 ab 1234' -> 'TN09AB1234' (spaces and hyphens removed, upper case)."""
    return text.replace(" ", "").replace("-", "").upper()      # TODO 1

def is_valid(reg):
    """Valid form: 2 letters, 2 digits, 1 or 2 letters, 4 digits (e.g. TN09AB1234)."""
    if len(reg) not in (9, 10):                                  # TODO 2
        return False
    series = reg[4:-4]                      # 1 or 2 characters
    return (reg[:2].isalpha() and reg[2:4].isdigit()
            and series.isalpha() and reg[-4:].isdigit())

def format_plate(reg):
    return f"{reg[:2]} {reg[2:4]} {reg[4:-4]} {reg[-4:]}"

for raw in ["tn 09 ab 1234", "KA-01-M-0007", "TN9AB1234", "TN 22 1234 AB"]:
    reg = normalise(raw)
    print(f"{raw:15} -> {reg:11} {'valid' if is_valid(reg) else 'INVALID'}")

print("\n-- Six designed inputs: prediction vs observed --")
cases = [("tn 09 ab 1234", True), ("TN-09-AB-1234", True), ("Tn09Ab1234", True),
         ("MH 12 A 0001", True), ("TN 09 ABC 1234", False), ("TN 0A AB 1234", False)]
for raw, pred in cases:
    reg = normalise(raw); obs = is_valid(reg)
    print(f"{raw:16} predicted={'valid' if pred else 'INVALID':7} observed={'valid' if obs else 'INVALID':7} "
          f"{'OK' if pred == obs else 'MISMATCH'}  formatted: {format_plate(reg) if obs else '-'}")

print("\n-- Inquiry --")
s9, s10 = "TN09A1234", "TN09AB1234"
print("s9 =", s9, " s9[-4:] =", s9[-4:], " s9[4:-4] =", repr(s9[4:-4]))
print("s10=", s10, " s10[-4:] =", s10[-4:], " s10[4:-4] =", repr(s10[4:-4]))
t = "tn09ab1234"; t.upper(); print("t after t.upper() (result discarded):", t)
print("id before/after rebinding:", id(t) == id(t.upper()), "(different object created)")

# ---- Alternative: regular expression -----------------------------------
PATTERN = re.compile(r"[A-Z]{2}[0-9]{2}[A-Z]{1,2}[0-9]{4}")
def is_valid_re(reg): return PATTERN.fullmatch(reg) is not None
data = [normalise(r) for r, _ in cases] * 20000
for name, fn in [("slicing", is_valid), ("re.fullmatch", is_valid_re)]:
    s = time.perf_counter(); res = [fn(x) for x in data]
    print(f"{name:13}: {time.perf_counter()-s:.3f} s for {len(data):,} numbers")
print("Both agree on all inputs:", all(is_valid(x) == is_valid_re(x) for x in data[:6]))
