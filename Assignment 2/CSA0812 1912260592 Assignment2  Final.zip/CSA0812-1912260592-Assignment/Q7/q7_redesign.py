"""Q7 - Diagnose, Redesign and Validate.  Program chosen: Q6 plain recursion ways_naive(n)."""
import sys, time, tracemalloc
from collections import Counter

# ---------- A. Diagnose: which sub-problems are repeated? --------------------
per_arg = Counter()
def ways_naive_traced(n):
    per_arg[n] += 1
    if n <= 1: return 1
    return ways_naive_traced(n - 1) + ways_naive_traced(n - 2)

ways_naive_traced(5)
print("A. Calls per argument for n=5:", dict(sorted(per_arg.items(), reverse=True)),
      "| total =", sum(per_arg.values()))
per_arg.clear(); ways_naive_traced(25)
print("   n=25: distinct arguments =", len(per_arg), "| total calls =", sum(per_arg.values()),
      "| calls to ways(1) alone =", per_arg[1], "| calls to ways(0) alone =", per_arg[0])

# ---------- Original and redesigns, each counting additions & calls -------------
def original(n, c):
    c["calls"] += 1
    if n <= 1: return 1
    c["adds"] += 1
    return original(n - 1, c) + original(n - 2, c)

def redesign_dict(n, c, memo=None):                    # top-down with our own dictionary
    if memo is None: memo = {}
    c["calls"] += 1
    if n in memo: return memo[n]
    if n <= 1: memo[n] = 1; return 1
    c["adds"] += 1
    memo[n] = redesign_dict(n - 1, c, memo) + redesign_dict(n - 2, c, memo)
    return memo[n]

def redesign_loop(n, c):                               # bottom-up, only last two values kept
    a, b = 1, 1
    for _ in range(n - 1):
        c["adds"] += 1
        a, b = b, a + b
    return b

# ---------- D. Prediction before implementing ----------------------------------------
print("\nD. Prediction: original additions = F(n+1)-1 (exponential, ~1.618^n); "
      "redesign additions = n-1 (linear). For n=30: ~1,346,268 vs 29 additions "
      "(~46,000x fewer) and time should drop by a similar order.")

# ---------- E. Implement and validate -------------------------------------------------
print("\nE. Same inputs for all versions")
print(f"{'n':>3} | {'orig calls':>11} {'orig adds':>10} {'orig t(s)':>10} | {'dict calls':>10} {'dict adds':>9} {'dict t(s)':>10} | "
      f"{'loop adds':>9} {'loop t(s)':>10} | same")
for n in (10, 20, 25, 30, 35):
    c1, c2, c3 = Counter(), Counter(), Counter()
    s = time.perf_counter(); r1 = original(n, c1); t1 = time.perf_counter() - s
    s = time.perf_counter(); r2 = redesign_dict(n, c2); t2 = time.perf_counter() - s
    s = time.perf_counter(); r3 = redesign_loop(n, c3); t3 = time.perf_counter() - s
    print(f"{n:>3} | {c1['calls']:>11,} {c1['adds']:>10,} {t1:>10.4f} | {c2['calls']:>10} {c2['adds']:>9} {t2:>10.6f} | "
          f"{c3['adds']:>9} {t3:>10.7f} | {r1 == r2 == r3}")

print("\nLarge input n = 1000 (original cannot finish):")
c2, c3 = Counter(), Counter()
sys.setrecursionlimit(5000)
try:
    s = time.perf_counter(); r2 = redesign_dict(1000, c2); t2 = time.perf_counter() - s
    print(f"  dict redesign: calls={c2['calls']} adds={c2['adds']} t={t2:.6f}s (needs raised recursion limit)")
except RecursionError:
    print("  dict redesign: RecursionError")
sys.setrecursionlimit(1000)
try:
    redesign_dict(1000, Counter())
except RecursionError:
    print("  dict redesign with default limit 1000: RecursionError")
s = time.perf_counter(); r3 = redesign_loop(1000, c3); t3 = time.perf_counter() - s
print(f"  loop redesign: adds={c3['adds']} t={t3:.7f}s, default limit, no error; digits={len(str(r3))}")

# ---------- memory trade-off ------------------------------------------------------------
print("\nPeak memory (tracemalloc), n=900:")
sys.setrecursionlimit(5000)
for name, fn in (("dict memo", lambda: redesign_dict(900, Counter())), ("loop", lambda: redesign_loop(900, Counter()))):
    tracemalloc.start(); fn(); peak = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
    print(f"  {name:10}: {peak/1024:8.1f} KiB")
# where the original may still be preferable
c = Counter(); original(5, c)
print("\nF. For n<=10 the original needs only", c["calls"], "calls - it is the shortest, most readable code and the difference is invisible.")
