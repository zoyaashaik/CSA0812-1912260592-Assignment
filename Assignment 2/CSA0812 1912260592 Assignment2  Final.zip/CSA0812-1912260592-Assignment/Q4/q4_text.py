"""Q4 - Building long text: += vs join() vs f-string vs StringIO."""
import time, io, statistics

def make_items(n): return [f"Item{i}:Rs{i % 50}" for i in range(n)]

def build_plus(parts):
    text = ""
    for p in parts:
        text += p + ";"
    return text

def build_join(parts):
    return "".join([p + ";" for p in parts])           # TODO 1: single join call

def build_fstring_plus(parts):                         # (c) f-string for each line, still using +=
    text = ""
    for i, p in enumerate(parts):
        text += f"{p};"
    return text

def build_fstring_join(parts):                         # f-string per line, collected then joined
    return "".join([f"{p};" for p in parts])

def build_stringio(parts):
    buf = io.StringIO()
    for p in parts:
        buf.write(p); buf.write(";")
    return buf.getvalue()

def timed(fn, items):
    s = time.perf_counter(); r = fn(items); return r, time.perf_counter() - s

items = make_items(200_000)
start = time.perf_counter(); a = build_plus(items); t_plus = time.perf_counter() - start
start = time.perf_counter(); b = build_join(items); t_join = time.perf_counter() - start
print("same text:", a == b, "| length:", len(b))
print(f"+= time: {t_plus:.4f} s join time: {t_join:.4f} s")

print("\nRun   size   +=(s)   f-string+=(s)   join(s)   f-string+join(s)   StringIO(s)")
rows = {}
for n in (1_000, 10_000, 200_000):
    it = make_items(n)
    res = {k: [] for k in ("plus", "fplus", "join", "fjoin", "sio")}
    for run in range(3):
        for key, fn in (("plus", build_plus), ("fplus", build_fstring_plus), ("join", build_join),
                        ("fjoin", build_fstring_join), ("sio", build_stringio)):
            res[key].append(timed(fn, it)[1])
    rows[n] = {k: statistics.mean(v) for k, v in res.items()}
    for i in range(3):
        print(f"{i+1:>3} {n:>8,} {res['plus'][i]:8.4f} {res['fplus'][i]:12.4f} {res['join'][i]:10.4f} {res['fjoin'][i]:15.4f} {res['sio'][i]:13.4f}")
print("\nAVERAGES OF 3 RUNS")
print(f"{'lines':>9} {'+=':>9} {'f-str +=':>9} {'join':>9} {'f-str+join':>11} {'StringIO':>9}")
for n, r in rows.items():
    print(f"{n:>9,} {r['plus']:9.4f} {r['fplus']:9.4f} {r['join']:9.4f} {r['fjoin']:11.4f} {r['sio']:9.4f}")

# Evidence about immutability: object identity changes on each +=
s = ""; ids = set()
for i in range(5):
    s += "x"; ids.add(id(s))
print("\ndistinct string objects created by 5 '+=' operations:", len(ids))
