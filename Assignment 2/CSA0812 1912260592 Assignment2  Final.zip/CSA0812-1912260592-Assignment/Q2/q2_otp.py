"""Q2 - Loops that count attempts (OTP at a bank kiosk). Inputs are scripted so the run is repeatable."""
CORRECT = "482913"

def make_input(seq):
    it = iter(seq)
    return lambda prompt="": next(it)

# ---- Design 1: while loop ----------------------------------------------
def otp_while(read, max_attempts=3):
    attempts = 0
    while attempts < max_attempts:
        entry = read("Enter OTP: ").strip()
        if entry == "":
            print("  (blank - not counted)")
            continue                      # blank entry does NOT use an attempt
        attempts += 1                      # counter updated only for real attempts
        if entry == CORRECT:
            print("  Access granted")
            break                         # success leaves loop, skips else
        print(f"  Wrong OTP ({attempts}/{max_attempts})")
    else:
        print("  Account locked for 30 minutes")   # runs only if no break
        return False
    return True

# ---- Design 2: for with range(3) ---------------------------------------
def otp_for(read):
    for attempt in range(3):
        while True:                        # re-ask on blank without consuming range()
            entry = read("Enter OTP: ").strip()
            if entry != "":
                break
            print("  (blank - not counted)")
        if entry == CORRECT:
            print("  Access granted")
            break
        print(f"  Wrong OTP ({attempt+1}/3)")
    else:
        print("  Account locked for 30 minutes")
        return False
    return True

# ---- pass demo: placeholder branch for a future feature -----------------
def otp_demo_pass(entry):
    if entry == CORRECT:
        pass       # TODO: log successful login later - 'pass' keeps syntax valid
    else:
        print("  mismatch")

# ---- Changed condition: 2 extra attempts after correct security answer -----
def otp_with_security(read, security_ok):
    allowed, attempts, bonus_given = 3, 0, False
    while attempts < allowed:
        entry = read("Enter OTP: ").strip()
        if not entry:
            continue
        attempts += 1
        if entry == CORRECT:
            print("  Access granted"); return True
        print(f"  Wrong OTP ({attempts}/{allowed})")
        if attempts == allowed and not bonus_given and security_ok():
            allowed += 2; bonus_given = True
            print("  Security answer correct: +2 attempts")
    print("  Account locked for 30 minutes")
    return False

# ---- Wrong-place counter bug demo ---------------------------------------
def otp_bug(read):
    attempts = 0
    while attempts < 3:
        attempts += 1                      # BUG: counted BEFORE checking blank
        entry = read("Enter OTP: ").strip()
        if entry == "":
            continue                       # blank entry wrongly burns an attempt
        if entry == CORRECT:
            return "granted"
    return "locked"

# ---- Recursive alternative ----------------------------------------------
def otp_rec(read, left=3):
    if left == 0:
        print("  Account locked for 30 minutes"); return False
    entry = read("Enter OTP: ").strip()
    if entry == "":
        return otp_rec(read, left)
    if entry == CORRECT:
        print("  Access granted"); return True
    print(f"  Wrong OTP, {left-1} left")
    return otp_rec(read, left - 1)

print("== while: wrong, blank, wrong, right ==");  otp_while(make_input(["111111", "", "222222", CORRECT]))
print("== while: three wrong (lock) ==");          otp_while(make_input(["1", "2", "3"]))
print("== for:   wrong, blank, right ==");         otp_for(make_input(["1", "", CORRECT]))
print("== for:   three wrong (lock) ==");          otp_for(make_input(["1", "2", "3"]))
print("== pass demo =="); otp_demo_pass(CORRECT); otp_demo_pass("0")
print("== BUG demo: blank, blank, blank, correct -> ", otp_bug(make_input(["", "", "", CORRECT])), "(should have been granted)")
print("== changed condition: 3 wrong, security OK, then correct ==")
otp_with_security(make_input(["1", "2", "3", "4", CORRECT]), lambda: True)
print("== changed condition: security answer wrong ==")
otp_with_security(make_input(["1", "2", "3"]), lambda: False)
print("== recursive version: wrong, right ==");     otp_rec(make_input(["1", CORRECT]))
