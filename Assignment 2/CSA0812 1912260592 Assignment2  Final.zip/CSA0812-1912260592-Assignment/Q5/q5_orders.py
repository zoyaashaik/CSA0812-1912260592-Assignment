"""Q5 - Functions, parameters and scope: canteen order system."""
def add_item_buggy(item, order=[]):
    order.append(item)
    return order

def add_item(item, order=None):
    if order is None:            # TODO 1: new list on each call
        order = []
    order.append(item)
    return order

print(add_item_buggy("Tea"), add_item_buggy("Vada"))
print(add_item("Tea"), add_item("Vada"))
print("add_item_buggy.__defaults__ =", add_item_buggy.__defaults__)
print("add_item.__defaults__       =", add_item.__defaults__)

# -- positional / keyword / default -------------------------------------
def bill(price, qty=1, gst_rate=0.05):
    total = price * qty
    gst = round(total * gst_rate, 2)
    return total, gst, round(total + gst, 2)      # multiple values returned as a tuple
print("\npositional:", bill(20, 3))
print("keyword   :", bill(qty=2, price=15))
print("default   :", bill(10))
total, gst, grand = bill(40, 2, gst_rate=0.12)    # unpacking
print(f"unpacked  : total={total} gst={gst} grand={grand}")

# -- local, global, nonlocal ----------------------------------------------
count = 0                                         # global name
def local_demo():
    count = 100                                   # new LOCAL name, global untouched
    return count
def global_demo():
    global count
    count += 1                                    # needs 'global' to rebind
def make_counter():
    n = 0
    def inc():
        nonlocal n                                # rebinds the enclosing function's name
        n += 1
        return n
    return inc
print("\nlocal_demo() =", local_demo(), "| global count still", count)
global_demo(); global_demo(); print("after 2 x global_demo(), count =", count)
c = make_counter(); print("closure counter:", c(), c(), c())
try:
    def bad():
        count += 1
    bad()
except UnboundLocalError as e:
    print("without 'global':", type(e).__name__, "-", e)

# -- Alternative designs: explicit list from caller, and closure -------------
def add_explicit(item, order):
    return order + [item]                          # caller passes list, new list returned
def make_order():
    order = []
    def add(item):
        order.append(item)                         # list kept inside closure
        return list(order)
    return add

print("\n-- Test: three customers in sequence (add_item) --")
for i, items in enumerate([["Tea", "Vada"], ["Coffee"], ["Dosa", "Idli", "Pongal"]], 1):
    order = None
    for it in items:
        order = add_item(it, order)
    print(f"Customer {i}: {order}")
print("-- Same three with closures --")
for i, items in enumerate([["Tea", "Vada"], ["Coffee"], ["Dosa", "Idli", "Pongal"]], 1):
    add = make_order()
    for it in items:
        r = add(it)
    print(f"Customer {i}: {r}")
print("-- Buggy version on same three customers --")
for i, items in enumerate([["Tea", "Vada"], ["Coffee"], ["Dosa", "Idli", "Pongal"]], 1):
    for it in items:
        r = add_item_buggy(it)
    print(f"Customer {i}: {r}")
