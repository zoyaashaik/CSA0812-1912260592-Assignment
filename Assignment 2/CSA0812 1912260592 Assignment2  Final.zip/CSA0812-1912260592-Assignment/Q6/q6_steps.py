"""Q6 - Recursion and its limits: ways to climb n temple steps (1 or 2 at a time)."""
import sys, time
from functools import lru_cache

calls = 0

def ways_naive(n):
    """Ways to climb n temple steps taking 1 or 2 steps at a time."""
    global calls
    calls += 1
    if n <= 1:
        return 1
    return ways_naive(n - 1) + ways_naive(n - 2)

@lru_cache(maxsize=None)
def ways_memo(n):
    global calls
    calls += 1
    if n <= 1:                                   # TODO 1
        return 1
    return ways_memo(n - 1) + ways_memo(n - 2)

def ways_loop(n):
    a, b = 1, 1                                  # ways(0), ways(1)
    for _ in range(n - 1):
        a, b = b, a + b
    return b if n >= 1 else 1

calls = 0; print("naive:", ways_naive(25), "calls =", calls)
ways_memo.cache_clear()
calls = 0; print("memo :", ways_memo(25), "calls =", calls)

print("\nCorrectness check n=1..6 (hand: 1,2,3,5,8,13)")
print([ways_naive(n) for n in range(1, 7)], [ways_loop(n) for n in range(1, 7)])

print("\nGrowth investigation")
print(f"{'n':>3} {'naive calls':>12} {'predicted 2F(n+1)-1':>20} {'memo calls':>11} {'naive time(s)':>14}")
def fib(k):
    a, b = 0, 1
    for _ in range(k): a, b = b, a + b
    return a
for n in (10, 20, 25, 30):
    calls = 0; s = time.perf_counter(); ways_naive(n); tn = time.perf_counter() - s; cn = calls
    ways_memo.cache_clear(); calls = 0; ways_memo(n); cm = calls
    print(f"{n:>3} {cn:>12,} {2*fib(n+1)-1:>20,} {cm:>11} {tn:>14.4f}")

print("\nDeployment decision, n = 1000")
print("sys.getrecursionlimit() =", sys.getrecursionlimit())
ways_memo.cache_clear()
try:
    ways_memo(1000)
except RecursionError as e:
    print("RecursionError:", e)

sys.setrecursionlimit(5000)
ways_memo.cache_clear(); calls = 0; s = time.perf_counter(); r1 = ways_memo(1000); t_memo = time.perf_counter() - s
print(f"memo with limit 5000 : digits={len(str(r1))} calls={calls} time={t_memo:.6f}s")
s = time.perf_counter(); r2 = ways_loop(1000); t_loop = time.perf_counter() - s
print(f"loop (last two values): digits={len(str(r2))} time={t_loop:.6f}s  same answer: {r1 == r2}")

# naive at n=1000: not run; extrapolate from measured n=30
calls = 0; s = time.perf_counter(); ways_naive(30); t30 = time.perf_counter() - s; c30 = calls
phi = (1 + 5 ** 0.5) / 2
est_calls = c30 * phi ** (1000 - 30)
est_sec = t30 * phi ** (1000 - 30)
print(f"naive n=1000 NOT executed: estimated calls ~ {est_calls:.3e}, estimated time ~ {est_sec:.3e} s "
      f"(~{est_sec/3.15e7:.3e} years)")
sys.setrecursionlimit(1000)
