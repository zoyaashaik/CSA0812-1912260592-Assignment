# Task 4: Write Correct Expressions - the binary float trap
from decimal import Decimal, ROUND_HALF_UP

for fat in (4.2, 4.3):
    steps = (fat - 3.5) / 0.1
    print(f"fat {fat}: (fat - 3.5) / 0.1 = {steps!r}   int() -> {int(steps)}   round() -> {round(steps)}")

print()
print("Correct number of 0.1% steps for fat 4.2 is 7 and for fat 4.3 is 8.")
print("int() truncates 7.999999999999998 to 7, so fat 4.3 loses one step (Rs 0.40 per litre).")
print()
for fat in ("4.2", "4.3"):
    steps = ((Decimal(fat) - Decimal("3.5")) / Decimal("0.1")).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    print(f"Decimal: fat {fat} -> {steps} steps (exact)")
