"""
Rate card of the village milk co-operative (used as a module).
"""
from decimal import Decimal, ROUND_HALF_UP

# Core Global Pricing Coefficients
BASE_RATE = Decimal('30.00')       # Rs per litre for standard milk (3.5% fat, 8.5% SNF)
FAT_STEP_VALUE = Decimal('0.40')   # Rs modifier per 0.1% fat deviation
SNF_STEP_VALUE = Decimal('0.30')   # Rs modifier per 0.1% SNF deviation


def rate_per_litre(fat, snf):
    fat_dec = Decimal(str(fat))
    snf_dec = Decimal(str(snf))
    # TODO 1: Quantize differences into discrete 0.1 steps
    fat_steps = ((fat_dec - Decimal('3.5')) / Decimal('0.1')).quantize(Decimal('1'), rounding=ROUND_HALF_UP)
    snf_steps = ((snf_dec - Decimal('8.5')) / Decimal('0.1')).quantize(Decimal('1'), rounding=ROUND_HALF_UP)
    final_rate = BASE_RATE + (fat_steps * FAT_STEP_VALUE) + (snf_steps * SNF_STEP_VALUE)
    return final_rate.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


def payout(litres, fat, snf):
    litres_dec = Decimal(str(litres))
    # TODO 2: Multiply litres by rate card matrix and quantize currency
    amount_payable = litres_dec * rate_per_litre(fat, snf)
    return amount_payable.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


if __name__ == "__main__":
    test_cases = [(10, 3.5, 8.5), (8.5, 4.2, 8.7), (12, 3.1, 8.3)]
    for litres, fat, snf in test_cases:
        rate = rate_per_litre(fat, snf)
        pay = payout(litres, fat, snf)
        print(f"{litres:5} L fat {fat} snf {snf} rate {rate:6.2f} pay {pay:8.2f}")
