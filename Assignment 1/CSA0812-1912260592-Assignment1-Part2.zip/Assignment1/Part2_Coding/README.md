# CSA0812 Assignment 1 - Part 2 (Coding) - Milk Co-operative System

Name: Zoyaa Shaik
Register Number: 1912260592
Python version: 3.15.2 (IDLE)
Libraries: standard library only (decimal)

## How to run (open the file in IDLE and press F5)
| Task | File | Result |
|------|------|--------|
| 2 | task02_interpreter_explorations.py | Types int, float, str, bool, list; 3.5, 3, 1, -4 |
| 4 | task04_float_trap.py | Shows the binary float trap and the Decimal fix |
| 7 | milkrate.py | Rates 30.00, 33.40, 27.80 and pays 300.00, 283.90, 333.60 |
| 11 & 12 | task11_12_seasonal_payout.py | Seasonal rates (April-June) and the 500-litre bonus |
