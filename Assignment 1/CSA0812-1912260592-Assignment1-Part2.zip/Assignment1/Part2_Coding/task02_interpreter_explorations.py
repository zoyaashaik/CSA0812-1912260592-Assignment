# Task 2: Explore Values and Types (same expressions as typed in the interactive shell)
print(type(10))
print(type(10.0))
print(type("10"))
print(type(True))
print(type([10, 8.5]))
print(7 / 2)     # true division
print(7 // 2)    # floor division
print(7 % 2)     # remainder
print(-7 // 2)   # floor division rounds toward minus infinity, so -4
