# Tasks 11 & 12: Day-4 design challenge - seasonal rates and high-volume bonus
from decimal import Decimal, ROUND_HALF_UP


def calculate_seasonal_payout(litres, fat, snf, month_string):
    litres_dec = Decimal(str(litres))
    fat_dec = Decimal(str(fat))
    snf_dec = Decimal(str(snf))
    month = month_string.strip().capitalize()

    # 1. Evaluate Seasonal Matrix Configurations
    if month in ["April", "May", "June"]:
        base_rate = Decimal('32.00')
        fat_step_value = Decimal('0.45')
    else:
        base_rate = Decimal('30.00')
        fat_step_value = Decimal('0.40')
    snf_step_value = Decimal('0.30')

    # 2. Step Extraction accommodating High-Precision inputs (e.g., 4.25% fat)
    fat_steps = ((fat_dec - Decimal('3.5')) / Decimal('0.1')).quantize(Decimal('1'), rounding=ROUND_HALF_UP)
    snf_steps = ((snf_dec - Decimal('8.5')) / Decimal('0.1')).quantize(Decimal('1'), rounding=ROUND_HALF_UP)

    # 3. Base structural calculations
    computed_rate = base_rate + (fat_steps * fat_step_value) + (snf_steps * snf_step_value)
    base_payout = (litres_dec * computed_rate).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

    # 4. Process Volume Incentive Threshold (> 500 Litres Bonus Check)
    if litres_dec > Decimal('500.00'):
        bonus = (litres_dec * Decimal('0.50')).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        return base_payout + bonus
    return base_payout


if __name__ == "__main__":
    tests = [(10, 3.5, 8.5, "March"), (10, 3.5, 8.5, "may"), (8.5, 4.2, 8.7, "June"),
             (520, 4.0, 8.5, "July"), (500, 4.0, 8.5, "July"), (10, 4.25, 8.5, "April")]
    print(f"{'litres':>7} {'fat':>5} {'snf':>5} {'month':>7} {'payout':>10}")
    for litres, fat, snf, month in tests:
        print(f"{litres:>7} {fat:>5} {snf:>5} {month:>7} {calculate_seasonal_payout(litres, fat, snf, month):>10}")
