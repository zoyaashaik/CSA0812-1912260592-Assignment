# Tasks 5 & 6: Input parsing with try/except and functions that return values
def read_number(prompt):
    """input() gives a str; keep asking until the text converts to a float."""
    while True:
        text = input(prompt)
        try:
            return float(text)
        except ValueError:
            print(f"'{text}' is not a number (for example 'eight' or '8,5'). Use digits and a dot.")


def is_valid(litres, fat, snf):
    """Pure function: returns True/False, prints nothing."""
    return litres >= 0 and 2.0 <= fat <= 7.0 and 6.0 <= snf <= 11.0


if __name__ == "__main__":
    litres = read_number("Litres: ")
    fat = read_number("Fat %: ")
    snf = read_number("SNF %: ")
    print("Valid entry" if is_valid(litres, fat, snf) else "Invalid entry constraints")
