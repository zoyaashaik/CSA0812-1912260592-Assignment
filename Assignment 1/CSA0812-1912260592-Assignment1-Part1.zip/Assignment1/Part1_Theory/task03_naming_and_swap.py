# Task 3: Choose Variables and Name the Constants (PEP 8)
BASE_PRICE = 30.00      # global business constants: UPPER_CASE
BASE_FAT = 3.5
BASE_SNF = 8.5

litres = 10.0           # runtime variables: lowercase snake_case
rate_per_litre = BASE_PRICE
amount = litres * rate_per_litre
print("amount:", amount)

# Atomic value swap with tuple unpacking, no temporary variable
a, b = 3.5, 8.5
print("before:", a, b)
a, b = b, a
print("after :", a, b)
