# Tasks 9 & 10: float vs Decimal accumulation at three scales (measured, not assumed)
import random
import time
from decimal import Decimal, ROUND_HALF_UP

def entry(rng):
    return (round(rng.uniform(1, 40), 1), round(rng.uniform(3.0, 5.0), 1), round(rng.uniform(8.0, 9.0), 1))

def float_amount(litres, fat, snf):
    rate = 30.0 + ((fat - 3.5) / 0.1) * 0.40 + ((snf - 8.5) / 0.1) * 0.30   # plain float arithmetic
    return litres * rate

def decimal_amount(litres, fat, snf):
    fs = ((Decimal(str(fat)) - Decimal("3.5")) / Decimal("0.1")).quantize(Decimal(1), ROUND_HALF_UP)
    ss = ((Decimal(str(snf)) - Decimal("8.5")) / Decimal("0.1")).quantize(Decimal(1), ROUND_HALF_UP)
    rate = Decimal("30.00") + fs * Decimal("0.40") + ss * Decimal("0.30")
    return (Decimal(str(litres)) * rate).quantize(Decimal("0.01"), ROUND_HALF_UP)

print(f"{'Scale':<28}{'float total':>18}{'Decimal total':>18}{'difference':>14}{'float s':>9}{'Decimal s':>10}")
for name, n in (("1 Centre (300)", 300), ("1 Block (6,000)", 6000), ("District Union (150,000)", 150000)):
    rng = random.Random(1)
    data = [entry(rng) for _ in range(n)]
    t0 = time.perf_counter(); f_total = 0.0
    for litres, fat, snf in data:
        f_total += float_amount(litres, fat, snf)
    t1 = time.perf_counter(); d_total = Decimal("0")
    for litres, fat, snf in data:
        d_total += decimal_amount(litres, fat, snf)
    t2 = time.perf_counter()
    print(f"{name:<28}{f_total:>18,.6f}{d_total:>18,.2f}{f_total - float(d_total):>14.6f}{t1 - t0:>9.3f}{t2 - t1:>10.3f}")
