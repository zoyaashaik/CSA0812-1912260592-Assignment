# CSA0812 Assignment 1 - Part 1 (Theory) - Milk Co-operative System

Name: Zoyaa Shaik
Register Number: 1912260592
Python version: 3.15.2 (IDLE)
Libraries: standard library only (decimal, random, time)

## How to run (open the file in IDLE and press F5)
| Task | File | What it shows |
|------|------|---------------|
| 3 | task03_naming_and_swap.py | UPPER_CASE constants, snake_case variables, tuple swap `a, b = b, a` |
| 5 & 6 | task05_06_input_and_functions.py | input() parsing with try/except ValueError ('eight', '8,5'); functions that return values |
| 8 | task08_transaction_loop.py | The pseudocode as a working loop (uses milkrate.py): invalid lines skipped, grand total printed |
| 9 & 10 | task09_10_float_vs_decimal.py | float vs Decimal totals at 300, 6,000 and 150,000 entries, with timings |

milkrate.py is a copy of the module from Part 2 and must stay in the same folder as task08_transaction_loop.py.
