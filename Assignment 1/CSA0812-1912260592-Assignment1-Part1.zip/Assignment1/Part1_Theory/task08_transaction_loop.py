# Task 8: the pseudocode implemented - transaction processing loop
from decimal import Decimal
from milkrate import payout


def run():
    total_ten_day_payout = Decimal("0.00")
    while True:
        farmer_id = input("Farmer id (END to finish): ").strip()
        if farmer_id.upper() == "END":
            break
        try:
            litres = float(input("Litres: "))
            fat = float(input("Fat %: "))
            snf = float(input("SNF %: "))
        except ValueError:
            print("Not a number. Skipping line item.")
            continue
        if litres < 0 or fat < 2.0 or fat > 7.0 or snf < 6.0 or snf > 11.0:
            print("Invalid entry constraints. Skipping line item.")
        else:
            entry_pay = payout(litres, fat, snf)
            total_ten_day_payout += entry_pay
            print(f"{farmer_id}: Rs. {entry_pay}")
    print("Grand Total Ledger Settlement Payout: Rs.", total_ten_day_payout)


if __name__ == "__main__":
    run()
