"""Q5 - List comprehension: cleaning cold-storage sensor readings."""
import random, sys, time

random.seed(7)
def make(n, kind="mixed"):
    if kind == "valid":
        return [round(random.uniform(-10, 30), 1) for _ in range(n)]
    if kind == "invalid":
        return [random.choice([55.0, 80.5, -60.0, -99.9]) for _ in range(n)]
    return [round(random.uniform(-70, 70), 1) if random.random() < 0.1 else round(random.uniform(-10, 30), 1) for _ in range(n)]

def to_f(c): return c * 9 / 5 + 32

# ---- 1) for loop with append ----------------------------------------------------------
def clean_loop(data):
    out = []
    for c in data:
        if -50 <= c <= 50:
            out.append((c, to_f(c)))
    return out
# ---- 2) list comprehension: [expression for item in data if condition] -------------------
def clean_comp(data):
    return [(c, to_f(c)) for c in data if -50 <= c <= 50]
# ---- 3) map() and filter() with lambda ------------------------------------------------------
def clean_map(data):
    return list(map(lambda c: (c, to_f(c)), filter(lambda c: -50 <= c <= 50, data)))

# ---- alarm minutes using enumerate ------------------------------------------------------------
def alarm_minutes(data):
    return [i for i, c in enumerate(data) if -50 <= c <= 50 and not 2 <= c <= 8]

small = [4.0, 60.0, 9.5, -70.0, 2.0, 8.0, 1.9, 8.1, 5.5, -51.0, 50.0, -50.0]
print("sample readings :", small)
print("valid (C, F)    :", clean_comp(small))
print("alarm minutes   :", alarm_minutes(small), " (valid readings outside 2-8 C)")
print("3 versions equal:", clean_loop(small) == clean_comp(small) == clean_map(small))

# ---- dictionary and set comprehension ------------------------------------------------------------
as_dict = {i: c for i, c in enumerate(small) if -50 <= c <= 50}
as_set = {round(c) for c in small if -50 <= c <= 50}
print("\ndict comprehension {minute: Celsius}:", as_dict)
print("set comprehension (distinct rounded C):", sorted(as_set))

# ---- list comprehension vs generator expression -----------------------------------------------------
print("\nlist comprehension :", type([c for c in small]).__name__, "| generator expression :", type((c for c in small)).__name__)
g = (c for c in small if -50 <= c <= 50)
print("sum via generator  :", sum(g), "| sum via list:", sum([c for c in small if -50 <= c <= 50]))
print("generator is exhausted after one pass:", list(g))

# ---- tests: all-valid and all-invalid -----------------------------------------------------------------
v, iv = make(1000, "valid"), make(1000, "invalid")
print("\nall valid  : kept", len(clean_comp(v)), "of 1000 | all invalid: kept", len(clean_comp(iv)), "of 1000 | empty list:", clean_comp([]))
print("identical results (all valid)  :", clean_loop(v) == clean_comp(v) == clean_map(v))
print("identical results (all invalid):", clean_loop(iv) == clean_comp(iv) == clean_map(iv))

# ---- timing -------------------------------------------------------------------------------------------------
def avg(fn, data, rep):
    s = time.perf_counter()
    for _ in range(rep): fn(data)
    return (time.perf_counter() - s) / rep
print("\n-- Time (seconds, average of repeats) --")
print(f"{'readings':>10} {'for+append':>11} {'list comp':>10} {'map+filter':>11} {'loop/comp':>10} {'map/comp':>9} {'same':>5}")
for n, rep in ((10_000, 30), (100_000, 5), (1_000_000, 2)):
    d = make(n)
    t1, t2, t3 = avg(clean_loop, d, rep), avg(clean_comp, d, rep), avg(clean_map, d, rep)
    print(f"{n:>10,} {t1:>11.5f} {t2:>10.5f} {t3:>11.5f} {t1/t2:>10.2f} {t3/t2:>9.2f} {str(clean_loop(d) == clean_comp(d) == clean_map(d)):>5}")

# ---- memory: list comprehension vs generator -------------------------------------------------------------------
print("\n-- Memory (sys.getsizeof of the container itself) --")
for n in (10_000, 100_000, 1_000_000):
    d = make(n)
    lst = [c for c in d if -50 <= c <= 50]
    gen = (c for c in d if -50 <= c <= 50)
    print(f"n={n:>9,}: list comprehension {sys.getsizeof(lst):>10,} bytes | generator {sys.getsizeof(gen):>4} bytes")

# ---- sum(...) with list vs generator: time and memory (alternative concept) ------------------------------------------
import tracemalloc
d = make(1_000_000)
tracemalloc.start(); s = time.perf_counter(); a = sum([c for c in d if -50 <= c <= 50]); t_l = time.perf_counter() - s; pk_l = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
tracemalloc.start(); s = time.perf_counter(); b = sum(c for c in d if -50 <= c <= 50); t_g = time.perf_counter() - s; pk_g = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
print(f"\nsum over 1,000,000 readings: list {t_l:.4f} s, peak {pk_l/1024:,.0f} KiB | generator {t_g:.4f} s, peak {pk_g/1024:,.1f} KiB | equal: {a == b}")
