"""Q4 - Sets: elective registration clash detection."""
import time, random

ai_elective = {"192311001", "192311004", "192311007", "192311009"}
iot_elective = {"192311002", "192311004", "192311009", "192311010"}
all_students = {f"1923110{i:02d}" for i in range(1, 11)}

# TODO 1 (set operators only)
both = ai_elective & iot_elective
exactly_one = ai_elective ^ iot_elective
neither = all_students - (ai_elective | iot_elective)

print("clash :", sorted(both))
print("exactly one:", sorted(exactly_one))
print("neither :", sorted(neither))

# ---- same result with set methods ------------------------------------------------------
both2 = ai_elective.intersection(iot_elective)
one2 = ai_elective.symmetric_difference(iot_elective)
neither2 = all_students.difference(ai_elective.union(iot_elective))
print("\nset methods give the same results:", both == both2, one2 == exactly_one, neither == neither2)
print("exactly_one == (AI - IoT) | (IoT - AI):", exactly_one == (ai_elective - iot_elective) | (iot_elective - ai_elective))

# ---- hand check for a small case ---------------------------------------------------------
A, B = {1, 2, 3}, {3, 4}
print("\nhand check A={1,2,3}, B={3,4}: A|B =", A | B, "(expect {1,2,3,4}); A&B =", A & B, "(expect {3}); A-B =", A - B, "(expect {1,2}); A^B =", A ^ B, "(expect {1,2,4})")

# ---- duplicates removed ----------------------------------------------------------------------
raw = ["192311001", "192311004", "192311001", "192311004", "192311007"]
print("\nlist with duplicate registrations:", raw)
print("set(raw) :", sorted(set(raw)), "| sorted report:", sorted(set(raw)))
try:
    {[1, 2]}
except TypeError as e:
    print("set containing a list ->", type(e).__name__ + ":", e)
print("set containing a tuple ->", {(1, 2), (1, 2)})

# ---- empty and identical electives ---------------------------------------------------------------
E = set()
print("\nempty vs AI  : & =", ai_elective & E, "| ^ =", len(ai_elective ^ E), "students (all of AI)")
print("identical     : & =", len(ai_elective & set(ai_elective)), "| ^ =", ai_elective ^ set(ai_elective), "| - =", ai_elective - set(ai_elective))

# ---- membership test: list vs set ----------------------------------------------------------------------
print("\n-- 'x in list' vs 'x in set' (searching for the LAST item = worst case for a list; average time per search) --")
print(f"{'n':>10} {'list (s)':>12} {'set (s)':>12} {'ratio':>10}")
for n in (10_000, 100_000, 1_000_000):
    L = [f"{i:09d}" for i in range(n)]; S = set(L)
    target = L[-1]
    reps = 200 if n <= 100_000 else 20
    s = time.perf_counter()
    for _ in range(reps): target in L
    tl = (time.perf_counter() - s) / reps
    s = time.perf_counter()
    for _ in range(reps * 50): target in S
    ts = (time.perf_counter() - s) / (reps * 50)
    print(f"{n:>10,} {tl:>12.7f} {ts:>12.9f} {tl/ts:>10,.0f}")

# ---- common students: nested loops vs & ---------------------------------------------------------------------
def common_nested(a, b):
    out = []
    for x in a:
        for y in b:
            if x == y:
                out.append(x); break
    return out
def common_sorted(a, b):                      # alternative: sort and walk both lists
    a, b = sorted(a), sorted(b); i = j = 0; out = []
    while i < len(a) and j < len(b):
        if a[i] == b[j]: out.append(a[i]); i += 1; j += 1
        elif a[i] < b[j]: i += 1
        else: j += 1
    return out
print("\n-- Finding common students (two lists of n and n, half in common) --")
print(f"{'n':>7} {'nested loops (s)':>17} {'sort+walk (s)':>14} {'set & (s)':>11} {'same':>6}")
random.seed(5)
for n in (500, 1000, 2000, 4000):
    pool = random.sample(range(10 * n), 2 * n)
    a = [str(x) for x in pool[:n]]; b = [str(x) for x in pool[n // 2: n // 2 + n]]
    s = time.perf_counter(); r1 = common_nested(a, b); t1 = time.perf_counter() - s
    s = time.perf_counter(); r2 = common_sorted(a, b); t2 = time.perf_counter() - s
    s = time.perf_counter(); r3 = set(a) & set(b); t3 = time.perf_counter() - s
    print(f"{n:>7,} {t1:>17.4f} {t2:>14.5f} {t3:>11.6f} {set(r1) == set(r2) == r3!s:>6}")
