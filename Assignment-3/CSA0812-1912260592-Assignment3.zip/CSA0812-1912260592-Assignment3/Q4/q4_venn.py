"""Venn diagrams for Q4 (saved as venn.png). The shaded area is computed from the set operation itself."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle
from matplotlib.colors import ListedColormap

ai = {"001", "004", "007", "009"}; iot = {"002", "004", "009", "010"}; allst = {f"{i:03d}" for i in range(1, 11)}
outside = sorted(allst - ai - iot)
ops = [("A & B   (clash: in both)", lambda a, b: a & b), ("A ^ B   (exactly one)", lambda a, b: a ^ b),
       ("all - (A | B)   (neither)", lambda a, b: ~(a | b)), ("A | B   (union)", lambda a, b: a | b),
       ("A - B   (only AI)", lambda a, b: a & ~b), ("B - A   (only IoT)", lambda a, b: b & ~a)]
xs, ys = np.meshgrid(np.linspace(0, 10, 600), np.linspace(0, 7, 420))
inA = (xs - 3.8) ** 2 + (ys - 3.5) ** 2 <= 2.4 ** 2
inB = (xs - 6.2) ** 2 + (ys - 3.5) ** 2 <= 2.4 ** 2
fig, axes = plt.subplots(2, 3, figsize=(11, 6.8))
for ax, (title, f) in zip(axes.flat, ops):
    mask = f(inA, inB)
    ax.imshow(np.where(mask, 1, 0), extent=(0, 10, 0, 7), origin="lower", cmap=ListedColormap(["white", "#8fd3a0"]), vmin=0, vmax=1, aspect="equal")
    ax.add_patch(Circle((3.8, 3.5), 2.4, fill=False, ec="blue", lw=1.6)); ax.add_patch(Circle((6.2, 3.5), 2.4, fill=False, ec="red", lw=1.6))
    ax.add_patch(Rectangle((0.02, 0.02), 9.96, 6.96, fill=False, ec="black"))
    ax.text(2.9, 3.5, "\n".join(sorted(ai - iot)), ha="center", va="center", fontsize=8)
    ax.text(5.0, 3.5, "\n".join(sorted(ai & iot)), ha="center", va="center", fontsize=8)
    ax.text(7.1, 3.5, "\n".join(sorted(iot - ai)), ha="center", va="center", fontsize=8)
    ax.text(2.4, 6.0, "A = AI", color="blue", fontsize=8); ax.text(7.0, 6.0, "B = IoT", color="red", fontsize=8)
    ax.text(5, 0.35, "outside both: " + ", ".join(outside), ha="center", fontsize=6.5)
    ax.set_title(title, fontsize=10); ax.axis("off")
fig.suptitle("Q4 - Venn diagrams (last three digits of register numbers; green = result of the operation)", fontsize=10)
plt.tight_layout(); plt.savefig("venn.png", dpi=130)
print("saved venn.png")
