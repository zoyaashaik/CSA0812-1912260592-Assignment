"""Q2 - Tuples, mutability and copying: city bus-stop map."""
import copy, sys, time

rows, cols = 3, 4
bad = [[0] * cols] * rows                   # every row is the SAME list object
bad[0][1] = 7
good = [[0 for _ in range(cols)] for _ in range(rows)]      # TODO 1: separate list per row
good[0][1] = 7

print("bad :", bad)
print("good:", good)
print(bad[0] is bad[1], good[0] is good[1])

# Tuples are immutable, so they can be used as dictionary keys
stops = {(13.0827, 80.2707): "Chennai Central", (13.0418, 80.2341): "T. Nagar"}
print(stops[(13.0418, 80.2341)])

# ---- list as a dictionary key -------------------------------------------------------
try:
    stops[[13.0418, 80.2341]] = "x"
except TypeError as e:
    print("list as key ->", type(e).__name__ + ":", e)

# ---- id() evidence for the bug --------------------------------------------------------
print("\nids of rows (bad) :", [id(r) for r in bad])
print("ids of rows (good):", [id(r) for r in good])

# ---- aliasing, shallow copy, deep copy ----------------------------------------------------
orig = [[1, 2], [3, 4]]
alias = orig
shallow1 = copy.copy(orig)
shallow2 = orig[:]
deep = copy.deepcopy(orig)
orig[0][0] = 99                              # change an INNER list
orig.append([5, 6])                          # change the OUTER list
print("\nafter orig[0][0]=99 and orig.append([5,6]):")
print("orig    :", orig)
print("alias   :", alias, "(same object:", alias is orig, ")")
print("copy.copy:", shallow1, "(inner list shared:", shallow1[0] is orig[0], ")")
print("slice [:]:", shallow2, "(inner list shared:", shallow2[0] is orig[0], ")")
print("deepcopy :", deep, "(inner list shared:", deep[0] is orig[0], ")")

# ---- unpacking tuples in a for loop ---------------------------------------------------
print()
for (lat, lon), name in stops.items():
    print(f"{name:16} lat={lat} lon={lon}")

# ---- function that changes its list argument ------------------------------------------------
def add_stop(route):
    route.append("New Stop")                 # mutates the caller's list
def add_stop_safe(route):
    return route + ["New Stop"]              # builds a new list
r = ["A", "B"]; add_stop(r); print("\nafter add_stop(r)      :", r)
r2 = ["A", "B"]; r3 = add_stop_safe(r2); print("after add_stop_safe(r2):", r2, "->", r3)

# ---- memory: list vs tuple of 1,000,000 values -----------------------------------------------
N = 1_000_000
L = list(range(N)); T = tuple(range(N))
print(f"\nsys.getsizeof(list of {N:,}) = {sys.getsizeof(L):,} bytes")
print(f"sys.getsizeof(tuple of {N:,}) = {sys.getsizeof(T):,} bytes")
print(f"list uses {sys.getsizeof(L) - sys.getsizeof(T):,} more bytes ({sys.getsizeof(L)/sys.getsizeof(T):.4f} x)")
LA = []
for i in range(N): LA.append(i)
print(f"list of {N:,} built by append() = {sys.getsizeof(LA):,} bytes (spare room kept for growth: {sys.getsizeof(LA) - sys.getsizeof(T):,} bytes more than the tuple)")
print("small example: list(range(5)) =", sys.getsizeof(list(range(5))), "bytes | tuple(range(5)) =", sys.getsizeof(tuple(range(5))), "bytes")

# ---- time: creating and indexing --------------------------------------------------------------
def best(fn, rep=5):
    t = []
    for _ in range(rep):
        s = time.perf_counter(); fn(); t.append(time.perf_counter() - s)
    return min(t)
print("\ncreate list  :", f"{best(lambda: list(range(N))):.4f} s")
print("create tuple :", f"{best(lambda: tuple(range(N))):.4f} s")
def idx(seq):
    def run():
        x = 0
        for i in range(N): x = seq[i]
    return run
print("index list   :", f"{best(idx(L), 3):.4f} s for {N:,} reads")
print("index tuple  :", f"{best(idx(T), 3):.4f} s for {N:,} reads")

# ---- a list stored inside a tuple ----------------------------------------------------------------
t = (1, [10, 20], 3)
t[1].append(30)
print("\ntuple with inner list after t[1].append(30):", t)
try:
    t[0] = 99
except TypeError as e:
    print("t[0] = 99 ->", type(e).__name__ + ":", e)
try:
    t[1] += [40]              # += on the inner list inside the tuple
except TypeError as e:
    print("t[1] += [40] ->", type(e).__name__ + ":", e)
print("but the inner list was still extended:", t)

# ---- alternative: sparse dictionary grid keyed by (row, col) ---------------------------------------
R, C = 1000, 1000
dense = [[0] * C for _ in range(R)]
sparse = {}
for k in range(1000):
    r_, c_ = (k * 37) % R, (k * 91) % C
    dense[r_][c_] += 1; sparse[(r_, c_)] = sparse.get((r_, c_), 0) + 1
size_dense = sys.getsizeof(dense) + sum(sys.getsizeof(row) for row in dense)
size_sparse = sys.getsizeof(sparse)
print(f"\ngrid {R}x{C}, 1,000 non-empty zones: dense list-of-lists ~ {size_dense:,} bytes | sparse dict ~ {size_sparse:,} bytes")
s = time.perf_counter()
for k in range(1_000_000): x = dense[k % R][(k * 7) % C]
td = time.perf_counter() - s
s = time.perf_counter()
for k in range(1_000_000): x = sparse.get((k % R, (k * 7) % C), 0)
ts = time.perf_counter() - s
print(f"1,000,000 reads: list of lists {td:.3f} s | dict {ts:.3f} s")
