"""Q6 - Nested data: a railway timetable (dict -> dict -> list of tuples + set)."""
import random, time, sys, tracemalloc

timetable = {
    12601: {"name": "Chennai Mail",        "route": [("Chennai Central", "--:--", "20:30"), ("Katpadi", "22:40", "22:45"), ("Salem", "01:30", "01:35"), ("Erode", "02:50", "02:55")], "days": {"Mon", "Wed", "Fri"}},
    12673: {"name": "Cheran Express",      "route": [("Chennai Central", "--:--", "22:00"), ("Salem", "03:10", "03:15"), ("Coimbatore", "05:45", "--:--")], "days": {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"}},
    12639: {"name": "Brindavan Express",   "route": [("Chennai Central", "--:--", "07:15"), ("Katpadi", "09:05", "09:07"), ("Salem", "11:50", "11:55"), ("Erode", "12:45", "12:47"), ("Coimbatore", "14:15", "--:--")], "days": {"Tue", "Thu", "Sat"}},
    22651: {"name": "Yercaud Express",     "route": [("Erode", "--:--", "06:00"), ("Salem", "07:00", "07:05"), ("Katpadi", "09:30", "09:35")], "days": {"Mon", "Fri"}},
    16021: {"name": "Kaveri Express",      "route": [("Salem", "--:--", "15:20"), ("Erode", "16:20", "16:22"), ("Coimbatore", "18:10", "--:--")], "days": {"Mon", "Wed", "Fri", "Sun"}},
}

print("Timetable")
print(f"{'Train':>6}  {'Name':<18} {'Days':<28} Route (station arr/dep)")
for no, t in timetable.items():
    days = ",".join(sorted(t["days"]))
    route = " -> ".join(f"{s} {a}/{d}" for s, a, d in t["route"])
    print(f"{no:>6}  {t['name']:<18} {days:<28} {route}")

# ---- expression for the departure time of the third station of a train -----------------------------------------------------
print("\ndeparture of 3rd station of train 12639 = timetable[12639]['route'][2][2] =", timetable[12639]["route"][2][2], "(Salem)")

# ---- trains that stop at a station on a day, sorted by departure from that station -----------------------------------------------------
def trains_at(tt, station, day):
    found = []
    for no, t in tt.items():
        if day in t["days"]:
            for s, arr, dep in t["route"]:
                if s == station:
                    found.append((no, t["name"], arr, dep))
    return sorted(found, key=lambda x: x[3])

print("\ntrains at Salem on Fri:")
for r in trains_at(timetable, "Salem", "Fri"): print("  ", r)
print("unknown station (Madurai) on Fri:", trains_at(timetable, "Madurai", "Fri"))
print("train 12639 does not run on Fri, so Brindavan is missing above; at Salem on Sat:", trains_at(timetable, "Salem", "Sat"))

# ---- index: station -> list of (train number, arr, dep) -----------------------------------------------------------------------------------
def build_index(tt):
    idx = {}
    for no, t in tt.items():
        for s, arr, dep in t["route"]:
            idx.setdefault(s, []).append((no, arr, dep))
    return idx

def trains_at_indexed(tt, idx, station, day):
    found = [(no, tt[no]["name"], arr, dep) for no, arr, dep in idx.get(station, []) if day in tt[no]["days"]]
    return sorted(found, key=lambda x: x[3])

index = build_index(timetable)
print("\nindex:", {s: [n for n, _, _ in v] for s, v in index.items()})
assert trains_at(timetable, "Salem", "Fri") == trains_at_indexed(timetable, index, "Salem", "Fri")
print("indexed result equals scan result for Salem/Fri: True")

# ---- experiment --------------------------------------------------------------------------------------------------------------------------------
random.seed(11)
STATIONS = [f"Station{i:02d}" for i in range(50)]
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
def make_tt(n, stops=10):
    tt = {}
    for k in range(n):
        route = [(s, f"{random.randint(0,23):02d}:{random.randint(0,59):02d}", f"{random.randint(0,23):02d}:{random.randint(0,59):02d}") for s in random.sample(STATIONS, stops)]
        tt[10000 + k] = {"name": f"Train{k}", "route": route, "days": set(random.sample(DAYS, random.randint(2, 7)))}
    return tt

print("\n-- Station queries (average of 200 queries, seconds per query) --")
print(f"{'trains':>7} {'stops':>8} {'scan':>12} {'with index':>12} {'speed-up':>9} {'index build (s)':>16} {'extra memory (KiB)':>19} {'same':>5}")
for n in (100, 1_000, 10_000):
    tt = make_tt(n)
    qs = [(random.choice(STATIONS), random.choice(DAYS)) for _ in range(200)]
    s = time.perf_counter(); idx = build_index(tt); tb = time.perf_counter() - s
    s = time.perf_counter(); r1 = [trains_at(tt, st, d) for st, d in qs]; t1 = (time.perf_counter() - s) / 200
    s = time.perf_counter(); r2 = [trains_at_indexed(tt, idx, st, d) for st, d in qs]; t2 = (time.perf_counter() - s) / 200
    tracemalloc.start(); build_index(tt); mem = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
    print(f"{n:>7,} {n*10:>8,} {t1:>12.6f} {t2:>12.7f} {t1/t2:>9.1f} {tb:>16.5f} {mem/1024:>19.1f} {str(r1 == r2):>5}")

# ---- the same queries WITHOUT the final sort (sorting costs the same in both versions) -------------------------------------------------------
def find_scan(tt, station, day):
    return [no for no, t in tt.items() if day in t["days"] and any(s == station for s, _, _ in t["route"])]
def find_indexed(tt, idx, station, day):
    return [no for no, _, _ in idx.get(station, []) if day in tt[no]["days"]]
print("\n-- Same queries without sorting the answer (seconds per query) --")
print(f"{'trains':>7} {'scan':>12} {'with index':>12} {'speed-up':>9}")
for n in (100, 1_000, 10_000):
    tt = make_tt(n); idx = build_index(tt)
    qs = [(random.choice(STATIONS), random.choice(DAYS)) for _ in range(200)]
    s = time.perf_counter(); r1 = [find_scan(tt, st, d) for st, d in qs]; t1 = (time.perf_counter() - s) / 200
    s = time.perf_counter(); r2 = [find_indexed(tt, idx, st, d) for st, d in qs]; t2 = (time.perf_counter() - s) / 200
    print(f"{n:>7,} {t1:>12.6f} {t2:>12.7f} {t1/t2:>9.1f}")

# ---- alternative: flat list of (train, station, arrival, departure, days) ----------------------------------------------------------------
def flat_scan(flat, station, day):
    return sorted([(no, name, a, d) for no, name, s, a, d, days in flat if s == station and day in days], key=lambda x: x[3])
tt = make_tt(1_000)
flat = [(no, t["name"], s, a, d, t["days"]) for no, t in tt.items() for s, a, d in t["route"]]
qs = [(random.choice(STATIONS), random.choice(DAYS)) for _ in range(200)]
s = time.perf_counter(); rf = [flat_scan(flat, st, d) for st, d in qs]; tf = (time.perf_counter() - s) / 200
rn = [trains_at(tt, st, d) for st, d in qs]
print(f"\nflat list of {len(flat):,} tuples: {tf:.6f} s per query | same answers as nested scan: {rf == rn}")
