"""Q1 - Lists and slicing: Daily rainfall records (village rain-gauge station)."""
import random, time
from collections import deque

random.seed(1)
def make_readings(n):
    # about 40 percent of days are dry (0 mm); wet days get 1-80 mm
    return [0 if random.random() < 0.4 else random.randint(1, 80) for _ in range(n)]

readings = make_readings(365)

# ---- weekly totals using slicing --------------------------------------
weeks = [sum(readings[i:i + 7]) for i in range(0, len(readings), 7)]
print("weeks:", len(weeks), "| last (partial) week has", len(readings[364:]), "day(s)")
print("first 5 weekly totals:", weeks[:5])
print("wettest week:", weeks.index(max(weeks)) + 1, "total", max(weeks), "mm | driest week:", weeks.index(min(weeks)) + 1, "total", min(weeks), "mm")

# ---- maximum / minimum with positions ---------------------------------
mx, mn = max(readings), min(readings)
print("max rainfall", mx, "mm on day", readings.index(mx) + 1, "| min rainfall", mn, "mm first on day", readings.index(mn) + 1)

# ---- slices explained (on a short list) -------------------------------
r = list(range(1, 22))              # 21 values: 1..21
print("\nreadings[7:14] =", r[7:14], " (items at index 7..13, second week)")
print("readings[-7:]  =", r[-7:], " (last 7 items)")
print("readings[::7]  =", r[::7], " (every 7th item starting at index 0)")

# ---- dry days -----------------------------------------------------------
dry_days = [i + 1 for i, v in enumerate(readings) if v == 0]
print("\ndry days:", len(dry_days), "first 10:", dry_days[:10])

# ---- 7-day moving average: naive vs running sum (with counting) -------------
def moving_naive(data, w=7):
    out, adds = [], 0
    for i in range(len(data) - w + 1):
        total = 0
        for v in data[i:i + w]:
            total += v; adds += 1
        out.append(total / w)
    return out, adds

def moving_running(data, w=7):
    if len(data) < w:
        return [], 0
    total = sum(data[:w]); adds = w
    out = [total / w]
    for i in range(w, len(data)):
        total += data[i] - data[i - w]; adds += 2      # one add + one subtract
        out.append(total / w)
    return out, adds

def moving_deque(data, w=7):
    win = deque(maxlen=w); total = 0; out = []
    for v in data:
        if len(win) == w:
            total -= win[0]
        win.append(v); total += v
        if len(win) == w:
            out.append(total / w)
    return out

print("\n-- Edge cases --")
print("empty list    :", moving_naive([])[0], moving_running([])[0], moving_deque([]))
print("shorter than 7:", moving_naive([5, 3, 1])[0], moving_running([5, 3, 1])[0], moving_deque([5, 3, 1]))
a, _ = moving_naive(readings); b, _ = moving_running(readings); c = moving_deque(readings)
print("all three agree on 365 readings:", all(abs(x - y) < 1e-9 and abs(x - z) < 1e-9 for x, y, z in zip(a, b, c)), "| windows:", len(a))

# ---- derived counts vs measured --------------------------------------------
print("\n-- Derived operation counts (additions/subtractions) vs counted --")
print(f"{'n':>8} {'naive derived 7(n-6)':>21} {'naive counted':>14} {'running derived 2n-7':>30} {'running counted':>16}")
for n in (365, 36_500, 365_000):
    d = make_readings(n)
    _, ca = moving_naive(d); _, cb = moving_running(d)
    print(f"{n:>8,} {7*(n-6):>21,} {ca:>14,} {7 + 2*(n-7):>30,} {cb:>16,}")

# ---- timings -------------------------------------------------------------------
def avg_time(fn, data, repeat):
    s = time.perf_counter()
    for _ in range(repeat): fn(data)
    return (time.perf_counter() - s) / repeat

print("\n-- Timing (seconds, average of repeats) --")
print(f"{'n':>8} {'naive':>10} {'running sum':>12} {'deque':>10} {'naive/running':>14}")
for n, rep in ((365, 200), (36_500, 5), (365_000, 2)):
    d = make_readings(n)
    tn = avg_time(moving_naive, d, rep); tr = avg_time(moving_running, d, rep); td = avg_time(moving_deque, d, rep)
    print(f"{n:>8,} {tn:>10.6f} {tr:>12.6f} {td:>10.6f} {tn/tr:>14.2f}")

# ---- cost of list.insert() --------------------------------------------------------
print("\n-- Cost of insert(0, x) vs append(x) at different sizes (1,000 operations, average per op) --")
for n in (365, 36_500, 365_000):
    d = make_readings(n)
    s = time.perf_counter()
    for _ in range(1000): d.insert(0, 5)
    ti = (time.perf_counter() - s) / 1000
    d = make_readings(n)
    s = time.perf_counter()
    for _ in range(1000): d.append(5)
    ta = (time.perf_counter() - s) / 1000
    print(f"n={n:>8,}: insert(0) {ti*1e6:9.2f} microseconds | append {ta*1e6:7.3f} microseconds")

# ---- alternative: dictionary keyed by date -----------------------------------------
import datetime
start = datetime.date(2026, 1, 1)
by_date = {start + datetime.timedelta(days=i): v for i, v in enumerate(readings)}
d0 = datetime.date(2026, 3, 10)
print("\nreading on", d0, "via dict:", by_date[d0], "| same via list index:", readings[(d0 - start).days])
