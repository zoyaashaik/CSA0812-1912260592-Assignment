"""Q3 - Dictionaries: Farmer helpline complaint analysis."""
import random, time
from collections import Counter

calls = [
    "seeds not received delayed",
    "fertiliser price high",
    "seeds price high subsidy not received",
]
STOP = {"not", "high"}

def frequencies(texts, stop):
    counts = {}
    for text in texts:
        for w in text.lower().split():
            if w not in stop:
                counts[w] = counts.get(w, 0) + 1          # TODO 1 (dict.get)
    return counts

def top(counts, k):
    return sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:k]    # TODO 2

print(top(frequencies(calls, STOP), 3))
print("price before received because both have count 2 and 'price' < 'received' alphabetically (key sorts by -count, then word)")
print("\nSame program with one more call 'seeds urgent' added (the sheet's expected output shows seeds = 3):")
print(top(frequencies(calls + ["seeds urgent"], STOP), 3))

# ---- setdefault grouping by district ------------------------------------------------------------
records = [("Salem", "seeds delayed"), ("Erode", "price high"), ("Salem", "no subsidy"), ("Madurai", "seeds not received"), ("Erode", "pump fault")]
by_district = {}
for d, text in records:
    by_district.setdefault(d, []).append(text)
print("\ncomplaints by district:", by_district)
print("count per district    :", {d: len(v) for d, v in by_district.items()})
cnt_setdefault = {}
for text in calls:
    for w in text.split():
        cnt_setdefault.setdefault(w, 0); cnt_setdefault[w] += 1          # setdefault version of counting
print("counting with setdefault matches get():", cnt_setdefault == frequencies(calls, set()))

# ---- views and order ------------------------------------------------------------------------------------
d = {"b": 2, "a": 1}
d["c"] = 3
print("\nkeys() :", d.keys(), "| values():", d.values(), "| items():", d.items())
print("insertion order kept (Python 3.7+):", list(d))
view = d.keys(); d["z"] = 26
print("views are live, after adding 'z':", view)

# ---- edge cases: empty text, case, punctuation -----------------------------------------------------------
print("\nempty text        :", frequencies([""], STOP))
print("upper/lower case   :", frequencies(["Seeds SEEDS seeds"], STOP))
import string
def clean(t): return t.lower().translate(str.maketrans("", "", string.punctuation))
print("with punctuation   :", frequencies(["Seeds, seeds! seeds."], STOP), "<- three different words")
print("after removing it  :", frequencies([clean("Seeds, seeds! seeds.")], STOP))

# ---- experiment ---------------------------------------------------------------------------------------------
random.seed(3)
VOCAB = ["seeds", "fertiliser", "price", "subsidy", "pump", "canal", "water", "loan", "pest", "market", "delayed", "received",
         "insurance", "tractor", "power", "credit", "storage", "transport", "rain", "soil"] + [f"w{i}" for i in range(80)]
def make(n): return [" ".join(random.choice(VOCAB) for _ in range(6)) for _ in range(n)]

def freq_count_method(texts, stop):
    words = [w for t in texts for w in t.split() if w not in stop]
    return {w: words.count(w) for w in set(words)}
def freq_counter(texts, stop):
    return Counter(w for t in texts for w in t.split() if w not in stop)

print("\nn complaints | dict+get (s) | setdefault (s) | list.count (s) | Counter (s) | same result")
for n in (1_000, 10_000, 100_000):
    data = make(n)
    res = {}
    for name, fn in (("get", frequencies), ("count", freq_count_method), ("counter", freq_counter)):
        if name == "count" and n == 100_000:
            sub = data[:10_000]
        s = time.perf_counter(); r = fn(data, STOP); res[name] = (time.perf_counter() - s, r)
    def sd(texts, stop):
        c = {}
        for t in texts:
            for w in t.split():
                if w not in stop:
                    c.setdefault(w, 0); c[w] += 1
        return c
    s = time.perf_counter(); r_sd = sd(data, STOP); t_sd = time.perf_counter() - s
    same = dict(res["get"][1]) == r_sd == dict(res["counter"][1]) == res["count"][1]
    print(f"{n:>12,} | {res['get'][0]:>12.4f} | {t_sd:>14.4f} | {res['count'][0]:>14.4f} | {res['counter'][0]:>11.4f} | {same}")
print("distinct words d =", len(VOCAB))
