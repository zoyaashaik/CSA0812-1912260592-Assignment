"""Q7 - Design a contact-merging program from first principles.

Stage 1 (interpret): input = list of contacts, each a dict with 'name', 'phones' (list of strings), 'emails' (list of strings).
  Output = list of merged people, each with all name spellings, normalised numbers and e-mails, each person once.
  Rule: two contacts are the SAME person if they share a normalised phone number OR a normalised e-mail
  (a name alone is NOT enough, because different people can have the same name).
  Requirements (measurable):
    R1 '+91 98400 12345', '9840012345', '098400-12345' normalise to the same 10-digit key '9840012345'.
    R2 'Dr. Ravi' and 'ravi kumar' do not decide identity; they are kept as spelling variants.
    R3 Contacts sharing a number or e-mail (directly or through a chain) end up in one merged person.
    R4 Contacts with missing fields are kept (no crash); a contact with no number and no e-mail stays separate.
    R5 Time grows about linearly with the number of contacts (target: 100,000 contacts in a few seconds).
"""
import random, re, time

TITLES = {"dr", "mr", "mrs", "ms", "prof", "shri", "smt"}

def norm_phone(p):
    digits = re.sub(r"\D", "", p)           # keep digits only
    return digits[-10:] if len(digits) >= 10 else digits   # drop +91 / leading 0
def norm_email(e): return e.strip().lower()
def norm_name(n):
    words = [w for w in re.sub(r"[^a-z ]", " ", n.lower()).split() if w not in TITLES]
    return " ".join(words)

# ------------- Design: dictionary keyed by normalised number / e-mail + union-find ----------------------------------------
def merge(contacts):
    parent = list(range(len(contacts)))
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = parent[x]
        return x
    owner = {}                               # normalised key -> index of first contact that had it
    for i, c in enumerate(contacts):
        keys = [("p", norm_phone(p)) for p in c.get("phones", []) if norm_phone(p)] + \
               [("e", norm_email(e)) for e in c.get("emails", []) if e.strip()]
        for k in keys:
            if k in owner:
                ra, rb = find(owner[k]), find(i)
                if ra != rb: parent[rb] = ra
            else:
                owner[k] = i
    groups = {}
    for i, c in enumerate(contacts):
        g = groups.setdefault(find(i), {"names": set(), "phones": set(), "emails": set()})
        if c.get("name"): g["names"].add(c["name"])
        g["phones"].update(norm_phone(p) for p in c.get("phones", []) if norm_phone(p))
        g["emails"].update(norm_email(e) for e in c.get("emails", []) if e.strip())
    return list(groups.values())

# ------------- Alternative: compare every pair of contacts, O(n^2) -----------------------------------------------------------
def keyset(c):
    return {("p", norm_phone(p)) for p in c.get("phones", []) if norm_phone(p)} | {("e", norm_email(e)) for e in c.get("emails", []) if e.strip()}
def merge_pairwise(contacts):
    parent = list(range(len(contacts)))
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = parent[x]
        return x
    ks = [keyset(c) for c in contacts]
    for i in range(len(contacts)):
        for j in range(i + 1, len(contacts)):
            if ks[i] & ks[j]:
                parent[find(j)] = find(i)
    return len({find(i) for i in range(len(contacts))})

# ------------- Verify by hand on a small list -----------------------------------------------------------------------------------------
small = [
    {"name": "Dr. Ravi",      "phones": ["+91 98400 12345"], "emails": []},
    {"name": "ravi kumar",    "phones": ["9840012345", "044-2345 6789"], "emails": ["Ravi@Mail.com"]},
    {"name": "R. Kumar",      "phones": [], "emails": ["ravi@mail.com"]},
    {"name": "Meena",         "phones": ["098765-43210"], "emails": []},
    {"name": "Ravi",          "phones": ["90000 11111"], "emails": []},        # different person, same first name
    {"name": "No Details",    "phones": [], "emails": []},                     # missing fields
    {"name": "Meena S",       "phones": ["+91 9876543210"], "emails": ["meena@x.in"]},
]
print("normalised:", norm_phone("+91 98400 12345"), norm_phone("9840012345"), norm_phone("098400-12345"), "| name:", norm_name("Dr. Ravi"), "/", norm_name("ravi kumar"))
print("\nExpected by hand: {Dr. Ravi, ravi kumar, R. Kumar} merge (shared number, then shared e-mail); {Meena, Meena S} merge; 'Ravi' (other number) stays separate; 'No Details' stays separate -> 4 people")
for g in merge(small):
    print("  person:", sorted(g["names"]), "| phones:", sorted(g["phones"]), "| emails:", sorted(g["emails"]))
print("people found:", len(merge(small)), "| pairwise method finds:", merge_pairwise(small))
print("empty list ->", merge([]))

# ------------- Measurements ------------------------------------------------------------------------------------------------------------------------
random.seed(21)
FIRST = ["ravi", "meena", "kumar", "anita", "suresh", "lakshmi", "arun", "divya", "karthik", "priya"]
def phone_variants(num):
    return random.choice([f"+91 {num[:5]} {num[5:]}", num, f"0{num[:5]}-{num[5:]}", f"+91-{num}", f"{num[:3]} {num[3:6]} {num[6:]}"])
def make_contacts(n):
    people = max(1, int(n * 0.6))                       # about 40 percent of entries are duplicates
    base = [{"num": f"{random.randint(6, 9)}{random.randint(0, 10**9 - 1):09d}", "mail": f"user{i}@mail.com", "name": f"{random.choice(FIRST)} {random.choice(FIRST)}"} for i in range(people)]
    out = []
    for i in range(n):
        p = base[i % people]
        c = {"name": random.choice(["Dr. ", "", "Mr. "]) + p["name"].title(), "phones": [], "emails": []}
        if random.random() < 0.9: c["phones"].append(phone_variants(p["num"]))
        if random.random() < 0.5: c["emails"].append(random.choice([p["mail"], p["mail"].upper()]))
        out.append(c)
    return out, people

print("\n-- Dictionary + union-find (the design) --")
print(f"{'contacts':>9} {'time (s)':>9} {'people found':>13} {'people generated':>17} {'contacts with no number/e-mail':>31}")
for n in (1_000, 10_000, 100_000):
    cs, people = make_contacts(n)
    s = time.perf_counter(); res = merge(cs); t = time.perf_counter() - s
    nokey = sum(1 for c in cs if not c["phones"] and not c["emails"])
    print(f"{n:>9,} {t:>9.4f} {len(res):>13,} {people:>17,} {nokey:>31,}")

print("\n-- Comparing every pair (alternative) --")
print(f"{'contacts':>9} {'pairs':>14} {'time (s)':>9} {'same people count':>18}")
times = {}
for n in (1_000, 2_000, 4_000):
    cs, _ = make_contacts(n)
    s = time.perf_counter(); k = merge_pairwise(cs); t = time.perf_counter() - s
    times[n] = t
    print(f"{n:>9,} {n*(n-1)//2:>14,} {t:>9.3f} {str(k == len(merge(cs))):>18}")
est = times[4_000] * (100_000 / 4_000) ** 2
print(f"extrapolated pairwise time for 100,000 contacts: ~{est:,.0f} s (~{est/60:.0f} minutes), because time grows with the square of n")
