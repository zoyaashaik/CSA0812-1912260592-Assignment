# CSA08 Assignment 5 - Data Acquisition, Cleaning, Analysis and AI Applications

Name: Zoyaa Shaik
Register Number: 1912260592D
Python version: 3.12 (IDLE)
Libraries: csv, io, sqlite3, re, statistics, cProfile (standard library); pandas and matplotlib (see requirements.txt)

## How to run (open each file in IDLE, press F5)
| Task | File | Result |
|------|------|--------|
| B1 | Task_B1/b1_cleaning.py | Cleans the CSV, prints `[0.0, 0.644, 1.0]`, rejects the 5000 test row, stores data in SQLite, saves two charts |
| B2 | Task_B2/b2_adversarial.py | Prints `54.0 108.0` and `None`; shows adversarial file, SQL and sentiment failures |
| B3 | Task_B3/b3_loops_vs_libs.py | Loops, pandas and SQL agree; timings at 1, 12 and 120 stations; cProfile report |
| B4 | Task_B4/b4_final_decision.py | Sentiment agreement on 50 complaints, summariser output, index before/after timing |

Part A (A1-A5) is design work and is in the PDF report.
Commit history: one commit per task.
