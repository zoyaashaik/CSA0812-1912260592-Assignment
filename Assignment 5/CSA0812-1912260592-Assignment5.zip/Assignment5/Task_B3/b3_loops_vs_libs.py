# Task B3: Loops vs Libraries vs SQL
import csv, io, random, time, sqlite3, cProfile, pstats
import pandas as pd
from collections import defaultdict

def make_data(stations, days=365, seed=1):
    random.seed(seed)
    out = ["station,day,pm25"]
    for s in range(stations):
        for d in range(days):
            for h in range(24):
                out.append(f"S{s},{d},{round(random.uniform(10,200),1)}")
    return "\n".join(out) + "\n"

def mean_loops(text):                       # plain python, one pass running sum/count
    tot, cnt = defaultdict(float), defaultdict(int)
    for r in csv.DictReader(io.StringIO(text)):
        k = (r["station"], int(r["day"]))
        tot[k] += float(r["pm25"]); cnt[k] += 1
    return {k: tot[k] / cnt[k] for k in tot}

def mean_pandas(text):
    df = pd.read_csv(io.StringIO(text))
    return df.groupby(["station", "day"])["pm25"].mean().to_dict()

def mean_sql(text):
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE r (station TEXT, day INT, pm25 REAL)")
    rows = ((r["station"], int(r["day"]), float(r["pm25"])) for r in csv.DictReader(io.StringIO(text)))
    con.executemany("INSERT INTO r VALUES (?,?,?)", rows)
    return {(s, d): m for s, d, m in con.execute("SELECT station, day, AVG(pm25) FROM r GROUP BY station, day")}

def mean_statistics(text):                  # alternative: store all, then statistics.mean
    import statistics
    store = defaultdict(list)
    for r in csv.DictReader(io.StringIO(text)):
        store[(r["station"], int(r["day"]))].append(float(r["pm25"]))
    return {k: statistics.mean(v) for k, v in store.items()}

# B3.1 correctness on small data
small = make_data(1, days=3)
r = [{k: round(v, 6) for k, v in f(small).items()} for f in (mean_loops, mean_pandas, mean_sql)]
print("B3.1 all three agree:", r[0] == r[1] == r[2])

# B3.2 timing at 1, 12, 120 stations
print("\nB3.2 timings (seconds)")
print(f"{'stations':>8} {'readings':>10} {'loops':>8} {'pandas':>8} {'sql':>8} {'stats.mean':>10}")
big = None
for n in (1, 12, 120):
    t = make_data(n)
    res = []
    for f in (mean_loops, mean_pandas, mean_sql, mean_statistics):
        s = time.perf_counter(); f(t); res.append(time.perf_counter() - s)
    print(f"{n:>8} {n*8760:>10} {res[0]:8.3f} {res[1]:8.3f} {res[2]:8.3f} {res[3]:10.3f}")
    if n == 12: big = t

# B3.3 profile the plain-python version
print("\nB3.3 cProfile of plain-Python loop version (12 stations)")
pr = cProfile.Profile(); pr.enable(); mean_loops(big); pr.disable()
pstats.Stats(pr).sort_stats("cumulative").print_stats(6)
