# Task B1: Implement and Validate the Cleaning Pipeline
import csv, io, sqlite3
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

RAW = """station,date,pm25
Adyar,2026-10-01,48
Adyar,2026-10-02,NA
Adyar,2026-10-03,
Guindy,2026-10-01,95
Guindy,2026-10-02,-5
Guindy,2026-10-03,121
"""

def load_clean(text):
    """Returns (station, date, pm25) tuples for valid, non-negative readings only."""
    rows = []
    for r in csv.DictReader(io.StringIO(text)):
        v = (r["pm25"] or "").strip()
        if v == "" or v.upper() == "NA":
            continue
        v = float(v)
        if v < 0 or v > 999:          # negative or impossibly large (sensor fault)
            continue
        rows.append((r["station"], r["date"], v))
    return rows

def min_max(values):
    lo, hi = min(values), max(values)
    return [round((v - lo) / (hi - lo), 3) for v in values]

clean = load_clean(RAW)
print(clean)
print(min_max([pm for _, _, pm in clean]))

# --- extra: test row for the >999 check ---
TEST = RAW + "Adyar,2026-10-04,5000\n"
print("With test row (5000 must be skipped):", load_clean(TEST))
assert len(load_clean(TEST)) == len(clean)

# --- B1.1 before / after ---
print("\nBEFORE cleaning:", len(RAW.strip().splitlines()) - 1, "rows")
print("AFTER  cleaning:", len(clean), "rows")

# --- B1.3 store in SQLite with executemany, answer queries ---
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
con.executemany("INSERT INTO aq VALUES (?,?,?)", clean)
con.commit()
print("\nQ1 average PM2.5 per station:", con.execute(
    "SELECT station, AVG(pm25) FROM aq GROUP BY station").fetchall())
print("Q2 worst day:", con.execute(
    "SELECT day, station, pm25 FROM aq ORDER BY pm25 DESC LIMIT 1").fetchall())
print("Q3 valid readings per station:", con.execute(
    "SELECT station, COUNT(*) FROM aq GROUP BY station").fetchall())

# --- B1.4 charts with labelled axes and titles ---
avg = con.execute("SELECT station, AVG(pm25) FROM aq GROUP BY station").fetchall()
plt.figure(figsize=(5, 3.5))
plt.bar([a[0] for a in avg], [a[1] for a in avg])
plt.xlabel("Station"); plt.ylabel("Mean PM2.5 (ug/m3)")
plt.title("Comparison of stations"); plt.tight_layout()
plt.savefig("chart_station_comparison.png")
plt.figure(figsize=(5, 3.5))
for s in ("Adyar", "Guindy"):
    pts = [(d, p) for st, d, p in clean if st == s]
    plt.plot([d[-2:] for d, _ in pts], [p for _, p in pts], marker="o", label=s)
plt.xlabel("Day of October 2026"); plt.ylabel("PM2.5 (ug/m3)")
plt.title("PM2.5 trend"); plt.legend(); plt.tight_layout()
plt.savefig("chart_trend.png")
print("Charts saved: chart_station_comparison.png, chart_trend.png")
