# Task B2: Engineer Adversarial Data
import sqlite3, csv, io

readings = [("Adyar", "2026-10-01", 48.0), ("Guindy", "2026-10-01", 95.0),
            ("Guindy", "2026-10-03", 121.0), ("Adyar", "2026-10-04", 60.0)]

con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
con.executemany("INSERT INTO aq VALUES (?,?,?)", readings)   # TODO 1
con.commit()

def station_average(name):
    row = con.execute("SELECT AVG(pm25) FROM aq WHERE station = ?", (name,)).fetchone()  # TODO 2
    return row[0]

print(station_average("Adyar"), station_average("Guindy"))
print(station_average("Adyar' OR '1'='1"))   # an injection attempt finds nothing

# ---------- Part 2: SQL string building vs ? placeholder ----------
print("\n--- Quote character in station name ---")
name = "O'Brien"
try:
    con.execute("SELECT AVG(pm25) FROM aq WHERE station = '" + name + "'")
    print("string-built: ran")
except sqlite3.Error as e:
    print("string-built (+): FAILS ->", e)
print("placeholder (?): ->", con.execute("SELECT AVG(pm25) FROM aq WHERE station = ?", (name,)).fetchone())

print("\n--- Injection with string building ---")
evil = "Adyar' OR '1'='1"
print("f-string rows returned:", con.execute(f"SELECT COUNT(*) FROM aq WHERE station = '{evil}'").fetchone()[0], "(all rows leaked!)")
print("placeholder rows returned:", con.execute("SELECT COUNT(*) FROM aq WHERE station = ?", (evil,)).fetchone()[0])

# ---------- Part 1: adversarial files ----------
def load(text, delimiter=","):
    rows = []
    for r in csv.DictReader(io.StringIO(text), delimiter=delimiter):
        rows.append((r["station"], r["date"], float(r["pm25"])))
    return rows

print("\n--- Adversarial files ---")
cases = {
    "missing column": "station,date\nAdyar,2026-10-01\n",
    "wrong delimiter": "station;date;pm25\nAdyar;2026-10-01;48\n",
    "empty file": "",
}
for k, t in cases.items():
    try:
        print(k, "->", load(t))
    except Exception as e:
        print(k, "-> %s: %r" % (type(e).__name__, e))

with open("latin1.csv", "wb") as f:
    f.write("station,date,pm25\nTambaram\u00e9,2026-10-01,50\n".encode("latin-1"))
try:
    open("latin1.csv", encoding="utf-8").read()
except UnicodeDecodeError as e:
    print("different encoding (latin-1 read as utf-8) -> UnicodeDecodeError:", e.reason)
print("fixed with encoding='latin-1':", load(open("latin1.csv", encoding="latin-1").read()))

# ---------- Adversarial sentiment inputs ----------
POSITIVE = {"good", "clean", "fast", "helpful", "improved"}
NEGATIVE = {"bad", "dirty", "slow", "rude", "smoke", "broken"}
NEGATORS = {"not", "never", "no"}
def score(text):
    words = text.lower().replace(".", " ").replace(",", " ").split()
    total = 0
    for i, w in enumerate(words):
        v = 1 if w in POSITIVE else -1 if w in NEGATIVE else 0
        if i > 0 and words[i-1] in NEGATORS:
            v = -v
        total += v
    return total
def label(t):
    s = score(t); return "positive" if s > 0 else "negative" if s < 0 else "neutral"

print("\n--- Adversarial sentiment ---")
for t in ["Oh great, the bus is slow again, wonderful service.",   # sarcasm
          "Not never helpful.",                                     # double negative
          "The roads are clean but the bus is slow and rude.",      # mixed
          "I would not say the staff were good."]:                  # negator not adjacent
    print(f"{label(t):8} | {t}")
