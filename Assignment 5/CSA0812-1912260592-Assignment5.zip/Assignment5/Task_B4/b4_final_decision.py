# Task B4: Final Engineering Decision
import sqlite3, random, time, re
from collections import Counter

POSITIVE = {"good", "clean", "fast", "helpful", "improved", "great", "quick", "excellent"}
NEGATIVE = {"bad", "dirty", "slow", "rude", "smoke", "broken", "polluted", "late", "noisy"}
NEGATORS = {"not", "never", "no"}
STOP = {"the", "a", "an", "is", "are", "was", "were", "and", "of", "in", "on", "to", "at", "for", "it", "this", "that", "very", "from", "with", "my", "our"}

def score(text):
    words = re.findall(r"[a-z']+", text.lower()); total = 0
    for i, w in enumerate(words):
        v = 1 if w in POSITIVE else -1 if w in NEGATIVE else 0
        if i and words[i-1] in NEGATORS: v = -v
        total += v
    return total
def label(t):
    s = score(t); return "positive" if s > 0 else "negative" if s < 0 else "neutral"

def summarise(text, k=1):
    sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]
    freq = Counter(w for w in re.findall(r"[a-z']+", text.lower()) if w not in STOP)
    ranked = sorted(sents, key=lambda s: sum(freq[w] for w in re.findall(r"[a-z']+", s.lower())), reverse=True)
    return " ".join(ranked[:k])

# ---- B4.1: 50 complaints, each written with a known intended meaning ----
random.seed(7)
areas = ["Adyar", "Guindy", "Velachery", "T Nagar", "Tambaram"]
T = [  # (template, my own reading)
 ("The air near {a} is bad and the smoke is terrible.", "negative"),
 ("Garbage burning in {a} makes the air dirty.", "negative"),
 ("The bus service in {a} is slow and the staff were rude.", "negative"),
 ("Roads in {a} are broken and dusty.", "negative"),
 ("The staff at the {a} office were not helpful.", "negative"),
 ("Roads in {a} are clean and the bus was fast.", "positive"),
 ("Air quality in {a} has improved a lot.", "positive"),
 ("The staff at the {a} office were helpful.", "positive"),
 ("Service in {a} was good and quick.", "positive"),
 ("Oh great, another slow bus in {a}, wonderful.", "negative"),      # sarcasm
 ("Not bad, the {a} service improved.", "positive"),
 ("The roads are clean but the bus is slow and rude in {a}.", "negative"),  # mixed
 ("Water supply in {a} stopped for two days.", "negative"),          # no lexicon word
]
data = [(t.format(a=random.choice(areas)), mine) for t, mine in (random.choice(T) for _ in range(50))]
agree = 0
for c, mine in data:
    if label(c) == mine: agree += 1
    else: print("  disagree: scorer =", label(c), "| my reading =", mine, "|", c)
print(f"B4.1 sentiment agreement with my reading: {agree}/50 ({agree*2}%)")
print("Summary (2 sentences) of first 5 complaints:", summarise(" ".join(c for c, _ in data[:5]), k=2))

# ---- B4.2: index effect on slowest query ----
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
rows = [(f"S{s}", f"2026-{1+d//30:02d}-{1+d%30:02d}", random.uniform(10, 200)) for s in range(120) for d in range(360) for _ in range(5)]
con.executemany("INSERT INTO aq VALUES (?,?,?)", rows)
q = "SELECT AVG(pm25) FROM aq WHERE station = 'S77' AND day = '2026-06-15'"
def timeit(n=200):
    s = time.perf_counter()
    for _ in range(n): con.execute(q).fetchone()
    return (time.perf_counter() - s) / n * 1000
before = timeit()
print("plan before:", con.execute("EXPLAIN QUERY PLAN " + q).fetchall()[0][-1])
con.execute("CREATE INDEX idx_station_day ON aq(station, day)")
after = timeit()
print("plan after :", con.execute("EXPLAIN QUERY PLAN " + q).fetchall()[0][-1])
print(f"\nB4.2 rows: {len(rows)}")
print(f"  query time before index: {before:.3f} ms")
print(f"  query time after index : {after:.3f} ms  -> about {before/after:.0f}x faster")
