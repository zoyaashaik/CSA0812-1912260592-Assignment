# Task 6 Stage 5: Implement and demonstrate the fest registration package
import os
from fest import reader, validator, writer

HERE = os.path.dirname(os.path.abspath(__file__))
INPUT = os.path.join(HERE, "fest_input")
OUT = os.path.join(HERE, "fest_output")
DEPARTMENTS = ["CSE", "ECE", "MECH", "CIVIL", "IT"]          # IT.txt does not exist

def main():
    os.makedirs(OUT, exist_ok=True)
    seen = set()                       # register numbers already accepted (O(1) look-up)
    master, errors, missing = [], [], []
    files_read = total_lines = duplicates = 0
    for dept in DEPARTMENTS:
        name = dept + ".txt"
        try:
            lines = reader.read_department(os.path.join(INPUT, name))
        except FileNotFoundError:
            missing.append(name)
            errors.append((name, "-", "department file is missing"))
            continue
        except UnicodeDecodeError:
            errors.append((name, "-", "file could not be decoded as UTF-8"))
            continue
        files_read += 1
        for number, text in lines:
            total_lines += 1
            try:
                record = validator.parse_registration(text)
            except validator.InvalidRegistration as e:
                errors.append((name, number, str(e)))
                continue
            if record["reg"] in seen:
                duplicates += 1
                errors.append((name, number, "duplicate registration %s removed" % record["reg"]))
                continue
            seen.add(record["reg"])
            master.append(record)
    writer.write_master(master, os.path.join(OUT, "master_list.csv"))
    per_event = writer.write_event_lists(master, os.path.join(OUT, "events"))
    writer.write_summary(os.path.join(OUT, "summary_report.txt"), files_read, missing,
                         total_lines, master, duplicates, len(errors), per_event)
    writer.write_errors(os.path.join(OUT, "error_log.txt"), errors)
    return master, errors, per_event

if __name__ == "__main__":
    master, errors, per_event = main()
    print("Master list (%d registrations):" % len(master))
    for r in master:
        print("  ", r["reg"], r["name"], r["dept"], ";".join(r["events"]))
    print("\nEvent-wise counts:", per_event)
    print("\nError log:")
    for name, number, message in errors:
        print("  %s line %s: %s" % (name, number, message))
    print("\n" + open(os.path.join(OUT, "summary_report.txt")).read())
