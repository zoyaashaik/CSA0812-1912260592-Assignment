import os

def read_department(path):
    """Return list of (line number, text) for one department file.
    Raises FileNotFoundError / UnicodeDecodeError for the caller to handle."""
    with open(path, encoding="utf-8") as f:
        return [(n, line.rstrip("\n")) for n, line in enumerate(f, start=1) if line.strip()]
