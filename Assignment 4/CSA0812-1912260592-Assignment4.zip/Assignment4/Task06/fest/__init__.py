"""fest package: reader, validator and writer for the college fest registration desk."""
