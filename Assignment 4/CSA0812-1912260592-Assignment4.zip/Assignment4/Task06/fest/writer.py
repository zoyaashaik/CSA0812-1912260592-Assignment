import os

def write_master(rows, path):
    with open(path, "w", encoding="utf-8") as f:
        f.write("reg,name,dept,email,events\n")
        for r in rows:
            f.write("%s,%s,%s,%s,%s\n" % (r["reg"], r["name"], r["dept"], r["email"], ";".join(r["events"])))

def write_event_lists(rows, folder):
    os.makedirs(folder, exist_ok=True)
    by_event = {}
    for r in rows:
        for e in r["events"]:
            by_event.setdefault(e, []).append(r)
    for event, people in sorted(by_event.items()):
        with open(os.path.join(folder, event.lower() + ".txt"), "w", encoding="utf-8") as f:
            for p in people:
                f.write("%s %s (%s)\n" % (p["reg"], p["name"], p["dept"]))
    return {e: len(p) for e, p in sorted(by_event.items())}

def write_summary(path, files_read, files_missing, total_lines, rows, duplicates, errors, per_event):
    with open(path, "w", encoding="utf-8") as f:
        f.write("FEST REGISTRATION SUMMARY\n")
        f.write("Department files read   : %d\n" % files_read)
        f.write("Department files missing: %s\n" % (", ".join(files_missing) or "none"))
        f.write("Lines read              : %d\n" % total_lines)
        f.write("Valid unique registrations: %d\n" % len(rows))
        f.write("Duplicates removed      : %d\n" % duplicates)
        f.write("Error lines logged      : %d\n" % errors)
        f.write("Participants per event  :\n")
        for e, n in per_event.items():
            f.write("   %-8s %d\n" % (e, n))

def write_errors(path, entries):
    with open(path, "w", encoding="utf-8") as f:
        for name, number, message in entries:
            f.write("%s line %s: %s\n" % (name, number, message))
