class InvalidRegistration(Exception):
    """Raised when a registration line is damaged or has an invalid field."""

def is_valid_email(email):
    """String-method validation: one '@', text before it, a dot inside the domain, no spaces."""
    email = email.strip()
    if " " in email or email.count("@") != 1:
        return False
    local, domain = email.split("@")
    return (local != "" and "." in domain and not domain.startswith(".")
            and not domain.endswith("."))

def parse_registration(text):
    """'regno,name,dept,email,event1;event2' -> dict, or raise InvalidRegistration."""
    parts = [p.strip() for p in text.split(",")]
    if len(parts) != 5:
        raise InvalidRegistration("expected 5 fields, found %d" % len(parts))
    reg, name, dept, email, events = parts
    if not reg.isdigit():
        raise InvalidRegistration("register number '%s' is not numeric" % reg)
    if not is_valid_email(email):
        raise InvalidRegistration("invalid e-mail '%s'" % email)
    event_list = [e.strip().title() for e in events.split(";") if e.strip()]
    if not event_list:
        raise InvalidRegistration("no event chosen")
    return {"reg": reg, "name": name.title(), "dept": dept.upper(), "email": email.lower(),
            "events": event_list}
