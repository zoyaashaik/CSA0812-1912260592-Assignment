# Task 2: Biometric attendance files -> monthly percentage, list below 75%, damaged-line log
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DAILY = os.path.join(HERE, "daily")

def process_month(folder):
    present, total, damaged = {}, {}, []
    for name in sorted(os.listdir(folder)):                      # one file per day
        if not name.endswith(".txt"):
            continue
        with open(os.path.join(folder, name), encoding="utf-8") as f:
            for number, line in enumerate(f, start=1):
                parts = line.strip().split(",")
                if len(parts) != 3:
                    damaged.append((name, number, "missing fields: " + line.strip()))
                    continue
                reg, date, status = parts
                if status not in ("P", "A"):
                    damaged.append((name, number, "wrong status letter '%s'" % status))
                    continue
                total[reg] = total.get(reg, 0) + 1
                present[reg] = present.get(reg, 0) + (status == "P")
    return present, total, damaged

present, total, damaged = process_month(DAILY)
with open(os.path.join(HERE, "attendance_summary.txt"), "w") as out, \
     open(os.path.join(HERE, "below_75.txt"), "w") as low:
    for reg in sorted(total):
        pct = 100 * present[reg] / total[reg]
        line = "%s  %d/%d  %.1f%%" % (reg, present[reg], total[reg], pct)
        out.write(line + "\n"); print(line)
        if pct < 75:
            low.write(line + "\n")
with open(os.path.join(HERE, "damaged_lines.log"), "w") as log:
    for name, number, why in damaged:
        log.write("%s line %d: %s\n" % (name, number, why))
print("Below 75%:", [r for r in sorted(total) if 100 * present[r] / total[r] < 75])
print("Damaged lines:")
for name, number, why in damaged:
    print("  %s line %d: %s" % (name, number, why))
