# Organisation (a): everything in ONE script
import os
DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sample_data")
OUT = os.path.dirname(os.path.abspath(__file__))

def read_files(folder):
    records = []
    for name in sorted(os.listdir(folder)):
        with open(os.path.join(folder, name), encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split(",")
                if len(parts) == 3 and parts[2] in ("P", "A"):
                    records.append(tuple(parts))
    return records

def percentages(records):
    present, total = {}, {}
    for reg, date, status in records:
        total[reg] = total.get(reg, 0) + 1
        present[reg] = present.get(reg, 0) + (status == "P")
    return {r: 100 * present[r] / total[r] for r in total}

def absent_three_consecutive(records):                  # added for Task 5.2
    streak, result = {}, set()
    for reg, date, status in sorted(records, key=lambda r: (r[0], r[1])):
        streak[reg] = streak.get(reg, 0) + 1 if status == "A" else 0
        if streak[reg] >= 3:
            result.add(reg)
    return sorted(result)

def write_report(pct, path):
    with open(path, "w") as f:
        for r in sorted(pct):
            f.write("%s %.1f%%\n" % (r, pct[r]))

if __name__ == "__main__":
    recs = read_files(DATA)
    pct = percentages(recs)
    write_report(pct, os.path.join(OUT, "report_a.txt"))
    print("Percentages:", {r: round(p, 1) for r, p in sorted(pct.items())})
    print("Below 75%:", [r for r in sorted(pct) if pct[r] < 75])
    print("Absent 3 days in a row:", absent_three_consecutive(recs))
