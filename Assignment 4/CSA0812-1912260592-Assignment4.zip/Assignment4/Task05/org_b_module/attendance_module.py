# Organisation (b): ONE module with all the functions, imported by a main script
import os

def read_files(folder):
    records = []
    for name in sorted(os.listdir(folder)):
        with open(os.path.join(folder, name), encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split(",")
                if len(parts) == 3 and parts[2] in ("P", "A"):
                    records.append(tuple(parts))
    return records

def percentages(records):
    present, total = {}, {}
    for reg, date, status in records:
        total[reg] = total.get(reg, 0) + 1
        present[reg] = present.get(reg, 0) + (status == "P")
    return {r: 100 * present[r] / total[r] for r in total}

def absent_three_consecutive(records):                  # added for Task 5.2
    streak, result = {}, set()
    for reg, date, status in sorted(records, key=lambda r: (r[0], r[1])):
        streak[reg] = streak.get(reg, 0) + 1 if status == "A" else 0
        if streak[reg] >= 3:
            result.add(reg)
    return sorted(result)

def write_report(pct, path):
    with open(path, "w") as f:
        for r in sorted(pct):
            f.write("%s %.1f%%\n" % (r, pct[r]))

if __name__ == "__main__":                              # test when run directly
    print("attendance_module run directly: self-test")
    print(percentages([("1", "d1", "P"), ("1", "d2", "A")]))
