import os
import attendance_module as am
HERE = os.path.dirname(os.path.abspath(__file__))
recs = am.read_files(os.path.join(HERE, "..", "sample_data"))
pct = am.percentages(recs)
am.write_report(pct, os.path.join(HERE, "report_b.txt"))
print("Percentages:", {r: round(p, 1) for r, p in sorted(pct.items())})
print("Below 75%:", [r for r in sorted(pct) if pct[r] < 75])
print("Absent 3 days in a row:", am.absent_three_consecutive(recs))
