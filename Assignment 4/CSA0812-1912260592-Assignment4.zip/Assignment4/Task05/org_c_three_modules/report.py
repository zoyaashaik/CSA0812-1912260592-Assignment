def write_report(pct, path):
    with open(path, "w") as f:
        for r in sorted(pct):
            f.write("%s %.1f%%\n" % (r, pct[r]))
