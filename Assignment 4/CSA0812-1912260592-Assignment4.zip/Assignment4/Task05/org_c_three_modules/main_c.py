import os
import reader, stats, report
HERE = os.path.dirname(os.path.abspath(__file__))
recs = reader.read_files(os.path.join(HERE, "..", "sample_data"))
pct = stats.percentages(recs)
report.write_report(pct, os.path.join(HERE, "report_c.txt"))
print("Percentages:", {r: round(p, 1) for r, p in sorted(pct.items())})
print("Below 75%:", [r for r in sorted(pct) if pct[r] < 75])
print("Absent 3 days in a row:", stats.absent_three_consecutive(recs))
