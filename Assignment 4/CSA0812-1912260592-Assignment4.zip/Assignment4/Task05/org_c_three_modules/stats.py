def percentages(records):
    present, total = {}, {}
    for reg, date, status in records:
        total[reg] = total.get(reg, 0) + 1
        present[reg] = present.get(reg, 0) + (status == "P")
    return {r: 100 * present[r] / total[r] for r in total}

def absent_three_consecutive(records):                  # added for Task 5.2
    streak, result = {}, set()
    for reg, date, status in sorted(records, key=lambda r: (r[0], r[1])):
        streak[reg] = streak.get(reg, 0) + 1 if status == "A" else 0
        if streak[reg] >= 3:
            result.add(reg)
    return sorted(result)
