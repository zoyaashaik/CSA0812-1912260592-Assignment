# Task 4.1 / 4.2: the ORIGINAL buggy program and a test that demonstrates each defect
import os
HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)

def save_returns(books):
    log = open("returns.log", "w")
    for b in books:
        log.write(b)
    log.close()

def process(day_file):
    try:
        books = open(day_file).read().split("\n")
        save_returns(books)
    except FileNotFoundError:
        print("missing")

# --- test data: three days of returned books ---
days = {"day1.txt": "Python Basics\nData Structures\n",
        "day2.txt": "Operating Systems\nNetworks\n",
        "day3.txt": "Algorithms\nDatabases\n"}
for name, text in days.items():
    with open(name, "w") as f:
        f.write(text)

for name in days:
    process(name)
print("Defects 1 and 2: log after processing 3 days:")
print(repr(open("returns.log").read()))
print("  -> only day 3 remains (mode 'w' erased days 1 and 2); the titles are joined")
print("     together (no newline written); the empty last element of split('\\n') is treated as a book.")

print("\nDefect 3: what happens to the open file when write() fails")
def save_returns_keep_log(books):
    log = open("returns.log", "w")
    for b in books:
        log.write(b)
    log.close()
try:
    save_returns_keep_log(["Python Basics", None, "Networks"])     # None cannot be written
except Exception as e:
    frame = e.__traceback__.tb_frame if e.__traceback__ is None else e.__traceback__.tb_next.tb_frame
    print("  error:", type(e).__name__ + ":", e)
    print("  log.closed =", frame.f_locals["log"].closed, "(close() was never reached, the file stays open)")
    print("  and 'process' would not catch it: its except only handles FileNotFoundError,")
    print("  so the program stops with no message saved.")
