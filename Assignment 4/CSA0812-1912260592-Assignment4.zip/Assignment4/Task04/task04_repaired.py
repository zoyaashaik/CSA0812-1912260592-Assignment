# Task 4.3: Repaired program - append mode, newline characters, with statements, error log
import os, logging
HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)

logging.basicConfig(filename="errors.log", filemode="w", level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")

def save_returns(books, log_path="returns.log"):
    with open(log_path, "a", encoding="utf-8") as log:      # "a" keeps earlier days
        for b in books:
            log.write(b + "\n")                              # one title per line

def process(day_file):
    try:
        with open(day_file, encoding="utf-8") as f:
            books = [line.strip() for line in f if line.strip()]   # skip empty lines
        save_returns(books)
        logging.info("processed %s (%d books)", day_file, len(books))
    except FileNotFoundError:
        logging.error("missing file: %s", day_file)
        print("missing:", day_file)
    except (OSError, UnicodeDecodeError, TypeError) as e:
        logging.error("failed on %s: %s: %s", day_file, type(e).__name__, e)
        print("failed:", day_file, "->", type(e).__name__)

if os.path.exists("returns.log"):
    os.remove("returns.log")
days = {"day1.txt": "Python Basics\nData Structures\n",
        "day2.txt": "Operating Systems\nNetworks\n",
        "day3.txt": "Algorithms\nDatabases\n"}
for name, text in days.items():
    with open(name, "w") as f:
        f.write(text)

for name in ["day1.txt", "day2.txt", "day_missing.txt", "day3.txt"]:
    process(name)

print("\nreturns.log after 3 days (plus one missing day):")
print(open("returns.log").read())
print("errors.log:")
print(open("errors.log").read())

try:                                                    # a failing write is also safe now
    save_returns(["Python Basics", None])
except TypeError as e:
    logging.error("write failed: %s", e)
    print("write failure handled, file closed by 'with'; earlier days still in returns.log:",
          "Python Basics" in open("returns.log").read() and "Databases" in open("returns.log").read())
