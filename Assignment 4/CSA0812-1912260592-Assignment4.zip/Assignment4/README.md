# CSA0812 Assignment 4 - Robust Data Processing with Files, Exceptions, Modules and Packages (CO4)

Name: Zoyaa Shaik
Register Number: 1912260592
Python version: 3.15.2 (IDLE)
Libraries: standard library only (os, decimal, logging, tempfile) - see requirements.txt

## How to run (open the file in IDLE and press F5)
| Task | File | Result |
|------|------|--------|
| 1 | Task01/task01_poor_script_demo.py | Shows the poor script silently loses lines (total 3080 instead of 5831.25) |
| 1 | Task01/task01_repaired.py | Correct total 5831.25, 2 rejected lines written to rejected_lines.txt |
| 2 | Task02/task02_attendance.py | Attendance %, students below 75%, damaged lines log |
| 3 | Task03/task03_complete_code.py | Expected output `(1, 1, [(3, 'expected 3 fields, found 2'), (4, "invalid status 'L'")])` |
| 3 | Task03/task03_exceptions_demo.py | Failure table, complete try statement, misuse experiment |
| 4 | Task04/task04_defects.py | Demonstrates the three defects of the original program |
| 4 | Task04/task04_repaired.py | Repaired program, returns.log keeps all days, errors.log |
| 5 | Task05/org_a_single_script/attendance_single.py | Organisation (a) |
| 5 | Task05/org_b_module/main_b.py | Organisation (b) |
| 5 | Task05/org_c_three_modules/main_c.py | Organisation (c) |
| 5 | Task05/org_d_package/main_d.py | Organisation (d) |
| 6 | Task06/run_fest.py | Fest registration package: master list, event files, summary, error log |

Sample input files are in the daily/, sample_data/ and fest_input/ folders. Output files and error logs are created next to the programs when they are run.
