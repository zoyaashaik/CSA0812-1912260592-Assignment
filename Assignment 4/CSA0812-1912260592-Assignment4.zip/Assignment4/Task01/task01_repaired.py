# Task 1.2: Repaired design - with statement, line-by-line, specific exceptions,
# list of rejected lines, and a function that takes the file name as a parameter.
import os
from decimal import Decimal, InvalidOperation

def total_bills(filename):
    """Return (total, report_lines, rejected) for a mess-bill file.
    Each line: register number, name, amount (paise allowed)."""
    total = Decimal("0")
    report_lines = []
    rejected = []                                   # (line number, text, reason)
    with open(filename, encoding="utf-8") as f:     # file is always closed
        for number, line in enumerate(f, start=1):  # one line in memory at a time
            line = line.strip()
            if not line:                            # ignore the empty last line
                continue
            parts = line.split(",")
            try:
                if len(parts) != 3:
                    raise ValueError("expected 3 fields, found %d" % len(parts))
                register, name, amount_text = parts
                amount = Decimal(amount_text)       # keeps paise exactly
            except ValueError as e:
                rejected.append((number, line, str(e)))
            except InvalidOperation:
                rejected.append((number, line, "amount '%s' is not a number" % amount_text))
            else:
                total += amount
                report_lines.append("%s %s" % (name, amount))
    return total, report_lines, rejected

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    total, report_lines, rejected = total_bills(os.path.join(here, "mess_oct.txt"))
    print("\n".join(report_lines))                  # one join instead of repeated +
    print("Total", total)
    print("Rejected lines:", len(rejected))
    with open(os.path.join(here, "rejected_lines.txt"), "w", encoding="utf-8") as out:
        for number, text, reason in rejected:
            out.write("line %d: %s  <- %s\n" % (number, text, reason))
            print("  line %d: %s  <- %s" % (number, text, reason))
