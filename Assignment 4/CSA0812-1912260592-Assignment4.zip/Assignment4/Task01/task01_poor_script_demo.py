# Task 1.1 evidence: the POOR script from the question, run on a small sample file
import os
HERE = os.path.dirname(os.path.abspath(__file__))
path = os.path.join(HERE, "mess_oct.txt")      # the original hard-codes C:\Users\Office\Desktop\mess_oct.txt

f = open(path)
data = f.read()
total = 0
report = ""
for line in data.split("\n"):
    try:
        parts = line.split(",")
        total = total + int(parts[2])
        report = report + parts[1] + " " + parts[2] + "\n"
    except:
        pass
print(report)
print("Total", total)
print("True total of the valid lines = 1250.50 + 980 + 1500.75 + 2100 =", 1250.50 + 980 + 1500.75 + 2100)
