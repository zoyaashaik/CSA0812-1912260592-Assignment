# Task 3.1 / 3.3 / 3.4: failure table evidence, complete try statement, misuse experiment
import os, tempfile

class InvalidRecord(Exception):
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
tmp = tempfile.mkdtemp()

# ---------- 3.1 every failure and its built-in exception ----------
print("--- 3.1 Failures observed ---")
def attempt(label, func):
    try:
        func()
        print("%-16s -> no error" % label)
    except Exception as e:
        print("%-16s -> %s: %s" % (label, type(e).__name__, e))

attempt("missing folder", lambda: os.listdir(os.path.join(tmp, "nofolder")))
attempt("missing file", lambda: open(os.path.join(tmp, "nofile.txt")))
attempt("permission", lambda: open(tmp))             # a folder cannot be opened as a file
bad = os.path.join(tmp, "bad.txt")
with open(bad, "wb") as f:
    f.write(b"192311001,2026-10-08,P\n\xff\xfe\n")
def read_bad():
    with open(bad, encoding="utf-8") as f:
        f.read()
attempt("wrong encoding", read_bad)
attempt("damaged (number)", lambda: int("1250.50"))
attempt("damaged (index)", lambda: "192311003,2026-10-08".split(",")[2])
empty = os.path.join(tmp, "empty.txt"); open(empty, "w").close()
def read_empty():
    with open(empty) as f:
        first = f.readline()
        return first.split(",")[2]
attempt("empty file", read_empty)

# ---------- 3.3 complete try statement with raise ... from ----------
print("\n--- 3.3 Complete try statement ---")
def parse_status(text):
    try:
        reg, date, status = text.strip().split(",")        # ValueError if wrong count
    except ValueError as e:
        raise InvalidRecord("cannot unpack %r" % text) from e   # keeps the original cause
    return status

def read_one(path):
    try:
        f = open(path, encoding="utf-8")
    except FileNotFoundError:
        print("  except FileNotFoundError: file missing")
        return None
    except UnicodeDecodeError:
        print("  except UnicodeDecodeError")
        return None
    else:
        print("  else: file opened, reading")
        with f:
            return parse_status(f.readline())
    finally:
        print("  finally: always runs (message or cleanup)")

good = os.path.join(tmp, "good.txt")
with open(good, "w") as g: g.write("192311001,2026-10-08,P\n")
print(read_one(good))
print(read_one(os.path.join(tmp, "missing.txt")))
try:
    parse_status("192311003,2026-10-08")
except InvalidRecord as e:
    print("InvalidRecord:", e, "| original cause:", repr(e.__cause__))

# ---------- 3.4 misuse experiment ----------
print("\n--- 3.4 Misuse experiment ---")
lines = ["192311001,2026-10-08,P", "192311002,2026-10-08,P", "192311003,2026-10-08,A"]

def count_present_blanket(lines):
    present = 0
    for line in lines:
        try:
            status = line.strip().split(",")[2]
            if statuss == "P":                    # typing error: 'statuss' instead of 'status'
                present += 1
        except Exception:
            pass                                  # blanket handler hides EVERY error
    return present

def count_present_specific(lines):
    present = 0
    for line in lines:
        try:
            status = line.strip().split(",")[2]
        except IndexError:                        # only the failure we expect
            continue
        if statuss == "P":                        # the same typing error
            present += 1
    return present

print("blanket 'except Exception: pass' returns:", count_present_blanket(lines), "(correct answer is 2, no error shown)")
try:
    count_present_specific(lines)
except NameError as e:
    print("specific except lets the bug show ->", type(e).__name__ + ":", e)
